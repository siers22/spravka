@echo off
cd /d "%~dp0App"
start "" "DemoExam.Wpf.exe"
