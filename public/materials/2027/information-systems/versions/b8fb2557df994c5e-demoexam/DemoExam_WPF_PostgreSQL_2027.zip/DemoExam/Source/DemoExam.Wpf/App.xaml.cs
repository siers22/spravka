using System.Windows;
using System.Windows.Threading;

namespace DemoExam.Wpf;

public partial class App : Application
{
    public App()
    {
        DispatcherUnhandledException += OnUnhandledException;
    }

    private void OnUnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
    {
        UiMessages.Error(e.Exception);
        e.Handled = true;
    }
}
