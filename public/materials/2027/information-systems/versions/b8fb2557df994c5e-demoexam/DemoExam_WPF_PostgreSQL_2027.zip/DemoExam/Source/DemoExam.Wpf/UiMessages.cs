using System.Windows;
using Npgsql;

namespace DemoExam.Wpf;

public static class UiMessages
{
    public static void Error(Exception exception)
    {
        string message = exception is InvalidOperationException
            ? exception.Message
            : "Не удалось выполнить действие. Проверьте, что PostgreSQL запущен, база demo_exam_2027 создана, а параметры в appsettings.json указаны правильно. Затем повторите действие.";
        MessageBox.Show(message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
    }

    public static void Info(string message) => MessageBox.Show(message, "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
}
