using System.Windows;
using DemoExam.Core;

namespace DemoExam.Wpf;

public partial class LoginWindow : Window
{
    public LoginWindow() { InitializeComponent(); LoginTextBox.Focus(); }

    private async void SignInButton_Click(object sender, RoutedEventArgs e)
    {
        SignInButton.IsEnabled = false;
        LoginStatusText.Text = "Проверяем данные…";
        try
        {
            var result = await Database.LoginAsync(LoginTextBox.Text, LoginPasswordBox.Password, LoginPuzzle.IsSolved);
            LoginStatusText.Text = result.Message;
            if (!result.Success)
            {
                MessageBox.Show(result.Message, "Ошибка входа", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            UiMessages.Info(result.Message);
            Window desktop = result.User!.Role == "Администратор" ? new AdminWindow(result.User) : new UserWindow(result.User);
            Hide();
            try { desktop.ShowDialog(); }
            finally
            {
                LoginPasswordBox.Clear();
                LoginPuzzle.Shuffle();
                LoginStatusText.Text = "Заполните оба поля и соберите пазл справа.";
                Show();
            }
        }
        catch (Exception ex) { LoginStatusText.Text = "Вход не выполнен. Проверьте подключение."; UiMessages.Error(ex); }
        finally { SignInButton.IsEnabled = true; }
    }
}
