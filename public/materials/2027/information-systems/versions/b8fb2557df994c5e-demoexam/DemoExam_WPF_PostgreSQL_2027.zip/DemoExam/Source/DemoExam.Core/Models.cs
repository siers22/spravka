namespace DemoExam.Core;

public class User
{
    public int Id { get; set; }
    public string Login { get; set; } = "";
    public string Role { get; set; } = "Пользователь";
    public bool IsBlocked { get; set; }
    public int FailedAttempts { get; set; }
}

public record LoginResult(bool Success, string Message, User? User = null);

public class Note
{
    public int Id { get; set; }
    public string Title { get; set; } = "";
    public string Content { get; set; } = "";
    public DateTime CreatedAt { get; set; }
}

public class OrderCost
{
    public string Number { get; set; } = "";
    public string Customer { get; set; } = "";
    public decimal MaterialsCost { get; set; }
    public decimal OperationsCost { get; set; }
    public decimal TotalCost { get; set; }
    public decimal SaleTotal { get; set; }
}
