using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using DemoExam.Core;

namespace DemoExam.Wpf;

public partial class PuzzleControl : UserControl
{
    private readonly PuzzleState puzzle = new();
    private readonly BitmapImage[] images = new BitmapImage[4];
    private int selectedPosition = -1;
    public bool IsSolved => puzzle.IsSolved;

    public PuzzleControl()
    {
        InitializeComponent();
        for (int i = 0; i < 4; i++)
            images[i] = new BitmapImage(new Uri($"pack://application:,,,/DemoExam.Wpf;component/Images/{i + 1}.png"));
        Shuffle();
    }

    public void Shuffle()
    {
        puzzle.Shuffle();
        selectedPosition = -1;
        Redraw();
    }

    private void Redraw()
    {
        PuzzleGrid.Children.Clear();
        for (int position = 0; position < 4; position++)
        {
            var button = new Button { Tag = position, Padding = new Thickness(0), Margin = new Thickness(0),
                Background = Brushes.White, BorderThickness = new Thickness(2),
                BorderBrush = position == selectedPosition ? Brushes.DodgerBlue : Brushes.LightGray,
                ToolTip = "Выберите два фрагмента для обмена", Content = new Image { Source = images[puzzle.Pieces[position]], Stretch = Stretch.Fill } };
            button.Click += PieceButton_Click;
            PuzzleGrid.Children.Add(button);
        }
        PuzzleHintText.Text = "После сборки нажмите «Войти».";
    }

    private void PieceButton_Click(object sender, RoutedEventArgs e)
    {
        int position = (int)((Button)sender).Tag;
        if (selectedPosition < 0) selectedPosition = position;
        else { puzzle.Swap(selectedPosition, position); selectedPosition = -1; }
        Redraw();
    }

    private void ShuffleButton_Click(object sender, RoutedEventArgs e) => Shuffle();

    private void ReferenceButton_Click(object sender, RoutedEventArgs e)
    {
        var grid = new UniformGrid { Rows = 2, Columns = 2, Width = 340, Height = 340, Background = Brushes.White };
        foreach (var image in images) grid.Children.Add(new Image { Source = image, Stretch = Stretch.Fill });
        var window = new Window { Title = "Исходное изображение", Content = grid, SizeToContent = SizeToContent.WidthAndHeight,
            ResizeMode = ResizeMode.NoResize, Owner = Window.GetWindow(this), WindowStartupLocation = WindowStartupLocation.CenterOwner };
        window.ShowDialog();
    }
}
