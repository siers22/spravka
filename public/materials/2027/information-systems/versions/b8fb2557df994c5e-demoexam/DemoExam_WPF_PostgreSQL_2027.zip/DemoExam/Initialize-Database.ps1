﻿param(
    [string]$HostName = '127.0.0.1',
    [int]$Port = 5432,
    [string]$UserName = 'postgres',
    [string]$Password = 'admin',
    [string]$DatabaseName = 'demo_exam_2027'
)
$ErrorActionPreference = 'Stop'
if ($DatabaseName -notmatch '^[a-z][a-z0-9_]*$') { throw 'Недопустимое имя базы данных.' }
$psql = 'C:\Program Files\PostgreSQL\18\bin\psql.exe'
if (-not (Test-Path -LiteralPath $psql)) {
    $psql = (Get-Command psql -ErrorAction Stop).Source
}
$previousPassword = $env:PGPASSWORD
$env:PGPASSWORD = $Password
$env:PGCLIENTENCODING = 'UTF8'
try {
    $exists = & $psql -h $HostName -p $Port -U $UserName -d postgres -w -At -v ON_ERROR_STOP=1 -c "SELECT 1 FROM pg_database WHERE datname = '$DatabaseName';"
    if ($LASTEXITCODE -ne 0) { throw 'Нет подключения к PostgreSQL. Проверьте адрес, порт, логин и пароль.' }
    if ($exists -eq '1') {
        Write-Host "База $DatabaseName уже существует. Её данные не изменены."
        return
    }
    & $psql -h $HostName -p $Port -U $UserName -d postgres -w -v ON_ERROR_STOP=1 -c "CREATE DATABASE $DatabaseName ENCODING 'UTF8';"
    if ($LASTEXITCODE -ne 0) { throw 'Не удалось создать базу данных.' }
    foreach ($file in @('01_schema.sql', '02_data.sql', '03_order_cost.sql')) {
        & $psql -h $HostName -p $Port -U $UserName -d $DatabaseName -w -v ON_ERROR_STOP=1 -f (Join-Path $PSScriptRoot "Database\$file")
        if ($LASTEXITCODE -ne 0) { throw "Ошибка при выполнении $file. Смотрите сообщение PostgreSQL выше." }
    }
    Write-Host "База $DatabaseName создана. Все исходные заказчики импортированы."
}
finally {
    if ($null -eq $previousPassword) { Remove-Item Env:\PGPASSWORD -ErrorAction SilentlyContinue }
    else { $env:PGPASSWORD = $previousPassword }
}
