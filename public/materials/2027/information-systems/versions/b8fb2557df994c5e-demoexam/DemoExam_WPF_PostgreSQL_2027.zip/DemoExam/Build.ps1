﻿$ErrorActionPreference = 'Stop'
Push-Location $PSScriptRoot
try {
    dotnet restore Source\DemoExam.sln --disable-parallel -m:1 -nr:false
    if ($LASTEXITCODE -ne 0) { throw 'Ошибка восстановления пакетов.' }
    dotnet build Source\DemoExam.sln -c Release --no-restore -m:1 -nr:false -p:UseSharedCompilation=false
    if ($LASTEXITCODE -ne 0) { throw 'Ошибка сборки.' }
    dotnet publish Source\DemoExam.Wpf -c Release --no-restore --self-contained false -o App
    if ($LASTEXITCODE -ne 0) { throw 'Ошибка публикации WPF.' }
    dotnet publish Source\DemoExam.Api -c Release --no-restore --self-contained false -o Api
    if ($LASTEXITCODE -ne 0) { throw 'Ошибка публикации API.' }
    dotnet publish Source\DemoExam.Checks -c Release --no-restore --self-contained false -o Checks
    if ($LASTEXITCODE -ne 0) { throw 'Ошибка публикации проверок.' }
}
finally { Pop-Location }
