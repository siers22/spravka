using System.Text;
using System.IO;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using DemoExam.Core;
using DemoExam.Wpf;
using Npgsql;

internal class Program
{
    private static int checks;
    private static readonly string prefix = "check_" + Guid.NewGuid().ToString("N")[..8];

    [STAThread]
    private static int Main(string[] args)
    {
        Console.OutputEncoding = Encoding.UTF8;
        try
        {
            if (args.Length == 2 && args[0] == "--render") { RenderWindows(args[1]); return 0; }
            RunChecksAsync().GetAwaiter().GetResult();
            Console.WriteLine($"Успешно: {checks} проверок.");
            return 0;
        }
        catch (Exception ex) { Console.WriteLine("FAIL: " + ex); return 1; }
    }

    private static void Check(bool condition, string description)
    {
        if (!condition) throw new Exception(description);
        checks++;
        Console.WriteLine("PASS: " + description);
    }

    private static async Task RunChecksAsync()
    {
        string hash = PasswordHelper.Hash("Пароль123");
        Check(PasswordHelper.Verify("Пароль123", hash), "Пароль с кириллицей проверяется корректно");
        Check(!PasswordHelper.Verify("пароль123", hash), "Регистр пароля учитывается");
        Check(hash != PasswordHelper.Hash("Пароль123"), "У каждого пароля случайная соль");
        Check(!PasswordHelper.Verify("anything", "broken"), "Повреждённый хеш не допускает вход");

        var puzzle = new PuzzleState();
        Check(puzzle.IsSolved, "Правильная последовательность фрагментов принимается");
        puzzle.Swap(0, 3);
        Check(!puzzle.IsSolved, "Неправильная последовательность отклоняется");
        puzzle.Swap(0, 3);
        Check(puzzle.IsSolved, "Обмен двух фрагментов работает");
        bool shuffled = true;
        for (int i = 0; i < 100; i++)
        {
            puzzle.Shuffle();
            shuffled &= !puzzle.IsSolved && puzzle.Pieces.Order().SequenceEqual(new[] { 0, 1, 2, 3 });
        }
        Check(shuffled, "Перемешивание не теряет фрагменты и не выдаёт готовый пазл");

        var adminResult = await Database.LoginAsync("admin", "admin", true);
        Check(adminResult.Success && adminResult.User!.Role == "Администратор", "Вход администратора по данным БД");
        int adminId = adminResult.User!.Id;
        try
        {
            var fresh = new User { Login = prefix, Role = "Пользователь" };
            await Database.SaveUserAsync(adminId, fresh, "original");
            var users = await Database.GetUsersAsync(adminId, prefix);
            Check(users.Count == 1, "Добавление пользователя администратором");
            int id = users[0].Id;

            bool duplicate = false;
            try { await Database.SaveUserAsync(adminId, new User { Login = prefix.ToUpperInvariant() }, "test"); }
            catch (InvalidOperationException) { duplicate = true; }
            Check(duplicate, "Повторный логин с другим регистром отклоняется");

            var empty = await Database.LoginAsync(prefix, "", true);
            Check(!empty.Success && (await Database.GetUsersAsync(adminId, prefix))[0].FailedAttempts == 0,
                "Пустые обязательные поля не считаются попыткой входа");
            Check(!(await Database.LoginAsync(prefix, "wrong", true)).Success, "Неверный пароль отклоняется");
            Check((await Database.GetUsersAsync(adminId, prefix))[0].FailedAttempts == 1, "Счётчик ошибок сохраняется в БД");
            Check((await Database.LoginAsync(prefix, "original", true)).Success, "Успешный вход до блокировки");
            Check((await Database.GetUsersAsync(adminId, prefix))[0].FailedAttempts == 0, "Успешный вход сбрасывает последовательность ошибок");

            await Database.LoginAsync(prefix, "wrong", true);
            await Database.LoginAsync(prefix, "original", false);
            var third = await Database.LoginAsync(prefix, "wrong", true);
            var saved = (await Database.GetUsersAsync(adminId, prefix))[0];
            Check(!third.Success && third.Message == Database.BlockedMessage && saved.IsBlocked && saved.FailedAttempts == 3,
                "Три смешанные ошибки пароля и пазла блокируют пользователя");
            Check((await Database.LoginAsync(prefix, "original", true)).Message == Database.BlockedMessage,
                "Правильный пароль не снимает блокировку");

            saved.IsBlocked = false;
            await Database.SaveUserAsync(adminId, saved, "");
            Check((await Database.LoginAsync(prefix, "original", true)).Success, "Администратор снимает блокировку, пустой пароль сохраняет прежний");
            saved.Login = prefix + "_new";
            await Database.SaveUserAsync(adminId, saved, "changed");
            Check(!(await Database.LoginAsync(prefix, "original", true)).Success, "После переименования старый логин не работает");
            Check((await Database.LoginAsync(saved.Login, "changed", true)).Success, "Изменение логина и пароля работает");

            bool forbidden = false;
            try { await Database.GetUsersAsync(id); } catch (InvalidOperationException) { forbidden = true; }
            Check(forbidden, "Обычный пользователь не получает интерфейс управления пользователями");
            forbidden = false;
            try { await Database.SaveUserAsync(id, new User { Login = prefix + "_attack" }, "test"); }
            catch (InvalidOperationException) { forbidden = true; }
            Check(forbidden, "Обычный пользователь не может добавлять учётные записи");

            // Проверяем три ошибки только капчи после успешного входа.
            await Database.LoginAsync(saved.Login, "changed", false);
            await Database.LoginAsync(saved.Login, "changed", false);
            Check((await Database.LoginAsync(saved.Login, "changed", false)).Message == Database.BlockedMessage,
                "Три неверно собранных пазла отдельно блокируют пользователя");
            saved.IsBlocked = false;
            await Database.SaveUserAsync(adminId, saved, "");
            saved.Role = "Администратор";
            await Database.SaveUserAsync(adminId, saved, "");
            Check((await Database.LoginAsync(saved.Login, "changed", true)).User?.Role == "Администратор",
                "Изменение роли применяется при следующем входе");

            Check((await Database.GetUsersAsync(adminId, "no_match_" + prefix)).Count == 0, "Поиск сообщает пустой результат");
            Check(!(await Database.LoginAsync("' OR 1=1 --", "test", true)).Success, "SQL-инъекция в логине не даёт войти");

            await CheckImportAsync();
            var costs = await Database.GetOrderCostsAsync();
            var order = costs.Single(c => c.Number == "1");
            Check(order.MaterialsCost == 9974.28m && order.OperationsCost == 4400m && order.TotalCost == 14374.28m,
                "Стоимость двух столов соответствует ценам и всем нормам спецификации");
            Check(order.SaleTotal == 26828m, "Продажная сумма учитывает скидку отдельно от себестоимости");
            await CheckSeveralProductsAsync();
            await ExpectSqlFailureAsync("INSERT INTO notes(title, content, id_user) VALUES ('test', 'test', 2147483647)", PostgresErrorCodes.ForeignKeyViolation,
                "Внешний ключ заметки не допускает несуществующего пользователя");
            await ExpectSqlFailureAsync("INSERT INTO users(login,password_hash,role) VALUES ('ADMIN','test','Пользователь')", PostgresErrorCodes.UniqueViolation,
                "Уникальность логина обеспечена и в PostgreSQL");
            await ExpectSqlFailureAsync("INSERT INTO materials(code,name,unit_id,unit_price) VALUES ('test','test',1,-1)", PostgresErrorCodes.CheckViolation,
                "Отрицательная цена отклоняется ограничением БД");
            var notes = await Database.GetNotesAsync(2);
            Check(notes.Count == 2 && notes.All(n => n.CreatedAt.Year == 2027), "Пользователь видит только свои заметки");

            string original = Database.ConnectionString;
            try
            {
                Database.ConnectionString = "Host=127.0.0.1;Port=1;Database=demo_exam_2027;Username=postgres;Password=admin;Timeout=1;Pooling=false";
                bool failed = false;
                try { await Database.GetNotesAsync(2); } catch (NpgsqlException) { failed = true; }
                Check(failed, "Сбой подключения возвращается вызывающему коду для обработки");
            }
            finally { Database.ConnectionString = original; }
        }
        finally
        {
            await using var c = await Database.OpenAsync();
            await using var command = new NpgsqlCommand("DELETE FROM users WHERE login = @old OR login = @new", c);
            command.Parameters.AddWithValue("old", prefix);
            command.Parameters.AddWithValue("new", prefix + "_new");
            await command.ExecuteNonQueryAsync();
        }
    }

    private static async Task CheckImportAsync()
    {
        string path = Path.Combine(AppContext.BaseDirectory, "..", "Database", "Customers.json");
        if (!File.Exists(path)) path = Path.Combine(Environment.CurrentDirectory, "outputs", "DemoExam", "Database", "Customers.json");
        using var source = JsonDocument.Parse(File.ReadAllText(path));
        await using var c = await Database.OpenAsync();
        bool identical = source.RootElement.GetArrayLength() == 6;
        foreach (var row in source.RootElement.EnumerateArray())
        {
            await using var command = new NpgsqlCommand("SELECT name,inn,address,phone,type FROM counterparties WHERE id = @id", c);
            command.Parameters.AddWithValue("id", row.GetProperty("id").GetString()!);
            await using var r = await command.ExecuteReaderAsync();
            identical &= await r.ReadAsync();
            if (r.HasRows)
                for (int i = 0; i < 5; i++) identical &= r.GetString(i) == row.GetProperty(new[] { "name", "inn", "addres", "phone", "type" }[i]).GetString();
        }
        Check(identical, "Все шесть записей JSON импортированы без потери полей и начальных нулей кода");
    }

    private static async Task CheckSeveralProductsAsync()
    {
        await using var c = await Database.OpenAsync();
        await using var tx = await c.BeginTransactionAsync();
        async Task<int> Insert(string sql)
        {
            await using var cmd = new NpgsqlCommand(sql, c, tx);
            cmd.Parameters.AddWithValue("code", prefix);
            return Convert.ToInt32(await cmd.ExecuteScalarAsync());
        }
        int product = await Insert("INSERT INTO products(code,name,unit_id) VALUES (@code,'Проверочный товар',1) RETURNING id");
        int specification = await Insert($"INSERT INTO specifications(product_id,name,manufacturer_id) VALUES ({product},'Проверочная спецификация','EXCEL-SELLER') RETURNING id");
        await using var add = new NpgsqlCommand($"""
            INSERT INTO specification_materials VALUES ({specification},1,2),({specification},2,3);
            INSERT INTO specification_operations VALUES ({specification},1,2,0.2),({specification},2,3,0.5);
            INSERT INTO customer_order_items(order_id,product_id,quantity,sale_price) VALUES (1,{product},3,10000);
            """, c, tx);
        await add.ExecuteNonQueryAsync();
        await using var cost = new NpgsqlCommand("SELECT total_cost FROM order_costs WHERE order_id = 1", c, tx);
        Check(Convert.ToDecimal(await cost.ExecuteScalarAsync()) == 38434.28m,
            "Несколько товаров, материалов и операций не перемножают строки расчёта");
        int emptyOrder = await Insert("INSERT INTO customer_orders(number,order_date,customer_id,executor_id) VALUES (@code,CURRENT_DATE,'EXCEL-BUYER','EXCEL-SELLER') RETURNING id");
        await using var empty = new NpgsqlCommand($"SELECT total_cost FROM order_costs WHERE order_id = {emptyOrder}", c, tx);
        Check(Convert.ToDecimal(await empty.ExecuteScalarAsync()) == 0,
            "Пустой заказ имеет нулевую стоимость");
        await tx.RollbackAsync();
    }

    private static async Task ExpectSqlFailureAsync(string sql, string expected, string description)
    {
        await using var c = await Database.OpenAsync();
        await using var tx = await c.BeginTransactionAsync();
        await using var cmd = new NpgsqlCommand(sql, c, tx);
        bool failed = false;
        try { await cmd.ExecuteNonQueryAsync(); } catch (PostgresException e) { failed = e.SqlState == expected; }
        await tx.RollbackAsync();
        Check(failed, description);
    }

    private static void RenderWindows(string directory)
    {
        Directory.CreateDirectory(directory);
        var app = new App();
        app.InitializeComponent();
        app.ShutdownMode = ShutdownMode.OnExplicitShutdown;
        var admin = new User { Id = 1, Login = "admin", Role = "Администратор" };
        var user = new User { Id = 2, Login = "user25", Role = "Пользователь" };
        var loginWindow = new LoginWindow();
        var adminWindow = new AdminWindow(admin);
        ((DataGrid)adminWindow.FindName("UsersGrid")).ItemsSource = Database.GetUsersAsync(1).GetAwaiter().GetResult();
        ((DataGrid)adminWindow.FindName("OrdersGrid")).ItemsSource = Database.GetOrderCostsAsync().GetAwaiter().GetResult();
        var userWindow = new UserWindow(user);
        ((DataGrid)userWindow.FindName("NotesGrid")).ItemsSource = Database.GetNotesAsync(2).GetAwaiter().GetResult();
        foreach (var (window, name) in new[] { (loginWindow as Window, "login"), (adminWindow as Window, "admin"), (userWindow as Window, "user") })
        {
            window.WindowStartupLocation = WindowStartupLocation.Manual;
            window.Left = -10000;
            window.Top = -10000;
            window.ShowInTaskbar = false;
            window.ShowActivated = false;
            window.Show();
            window.Dispatcher.Invoke(() => { }, DispatcherPriority.ApplicationIdle);
            var root = (FrameworkElement)window.Content;
            if (root is Grid grid) grid.Background = window.Background;
            window.UpdateLayout();
            int width = (int)window.ActualWidth;
            int height = (int)window.ActualHeight;
            var bitmap = new RenderTargetBitmap(width, height, 96, 96, PixelFormats.Pbgra32);
            bitmap.Render(window);
            var encoder = new PngBitmapEncoder();
            encoder.Frames.Add(BitmapFrame.Create(bitmap));
            using var output = File.Create(Path.Combine(directory, name + ".png"));
            encoder.Save(output);
            Console.WriteLine("Rendered " + name);
            window.Close();
        }
    }
}
