namespace DemoExam.Core;

public class PuzzleState
{
    public int[] Pieces { get; } = [0, 1, 2, 3];
    public bool IsSolved => Pieces.SequenceEqual(new[] { 0, 1, 2, 3 });

    public void Shuffle()
    {
        do { Random.Shared.Shuffle(Pieces); } while (IsSolved);
    }

    public void Swap(int first, int second)
    {
        if (first < 0 || first > 3 || second < 0 || second > 3)
            throw new ArgumentOutOfRangeException(nameof(first));
        (Pieces[first], Pieces[second]) = (Pieces[second], Pieces[first]);
    }
}
