using System.Windows;
using System.Windows.Controls;
using DemoExam.Core;

namespace DemoExam.Wpf;

public partial class AdminWindow : Window
{
    private readonly User currentUser;
    private int editedUserId;

    public AdminWindow(User user)
    {
        InitializeComponent();
        currentUser = user;
        AdminLoginText.Text = "Вы вошли как " + user.Login;
    }

    private async void AdminWindow_Loaded(object sender, RoutedEventArgs e)
    {
        try { await RefreshUsersAsync(); OrdersGrid.ItemsSource = await Database.GetOrderCostsAsync(); }
        catch (Exception ex) { UiMessages.Error(ex); }
    }

    private async Task RefreshUsersAsync()
    {
        var users = await Database.GetUsersAsync(currentUser.Id, SearchTextBox.Text);
        UsersGrid.ItemsSource = users;
        UsersStatusText.Text = users.Count == 0 ? "Пользователи не найдены. Измените поиск или очистите поле." : $"Найдено пользователей: {users.Count}";
    }

    private void UsersGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (UsersGrid.SelectedItem is not User user) return;
        editedUserId = user.Id;
        EditorTitleText.Text = "Изменение пользователя";
        UserLoginTextBox.Text = user.Login;
        UserPasswordBox.Clear();
        RoleComboBox.SelectedIndex = user.Role == "Администратор" ? 1 : 0;
        BlockedCheckBox.IsChecked = user.IsBlocked;
    }

    private void NewUserButton_Click(object sender, RoutedEventArgs e) => ClearEditor();

    private void ClearEditor()
    {
        editedUserId = 0;
        UsersGrid.SelectedItem = null;
        EditorTitleText.Text = "Новый пользователь";
        UserLoginTextBox.Clear();
        UserPasswordBox.Clear();
        RoleComboBox.SelectedIndex = 0;
        BlockedCheckBox.IsChecked = false;
        UserLoginTextBox.Focus();
    }

    private async void SaveUserButton_Click(object sender, RoutedEventArgs e)
    {
        SaveUserButton.IsEnabled = false;
        try
        {
            var user = new User { Id = editedUserId, Login = UserLoginTextBox.Text,
                Role = ((ComboBoxItem)RoleComboBox.SelectedItem).Content.ToString()!, IsBlocked = BlockedCheckBox.IsChecked == true };
            await Database.SaveUserAsync(currentUser.Id, user, UserPasswordBox.Password);
            UiMessages.Info("Данные пользователя сохранены.");
            await RefreshUsersAsync();
            ClearEditor();
        }
        catch (Exception ex) { UiMessages.Error(ex); }
        finally { SaveUserButton.IsEnabled = true; }
    }

    private async void SearchButton_Click(object sender, RoutedEventArgs e)
    {
        try { await RefreshUsersAsync(); }
        catch (Exception ex) { UiMessages.Error(ex); }
    }

    private async void RefreshOrdersButton_Click(object sender, RoutedEventArgs e)
    {
        try { OrdersGrid.ItemsSource = await Database.GetOrderCostsAsync(); }
        catch (Exception ex) { UiMessages.Error(ex); }
    }

    private void LogoutButton_Click(object sender, RoutedEventArgs e) => Close();
}
