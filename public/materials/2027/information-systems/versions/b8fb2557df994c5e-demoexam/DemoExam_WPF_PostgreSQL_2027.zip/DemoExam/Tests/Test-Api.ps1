﻿$ErrorActionPreference = 'Stop'
$rootDirectory = Split-Path $PSScriptRoot -Parent
$apiExecutable = Join-Path $rootDirectory 'Api\DemoExam.Api.exe'
$runtimeDirectory = Join-Path $PSScriptRoot 'runtime'
New-Item -ItemType Directory -Path $runtimeDirectory -Force | Out-Null
$normalProcess = $null
$errorProcess = $null
$oldConnection = $env:DEMO_DB_CONNECTION
$script:Passed = 0

function Read-Response([string]$Url) {
    try {
        $response = Invoke-WebRequest -Uri $Url -UseBasicParsing -TimeoutSec 10
        return @{ Code = [int]$response.StatusCode; Body = $response.Content; ContentType = $response.Headers['Content-Type'] }
    }
    catch {
        $response = $_.Exception.Response
        if ($null -eq $response) { throw }
        $reader = New-Object System.IO.StreamReader($response.GetResponseStream(), [System.Text.Encoding]::UTF8)
        try { $body = $reader.ReadToEnd() } finally { $reader.Dispose() }
        return @{ Code = [int]$response.StatusCode; Body = $body; ContentType = $response.ContentType }
    }
}

function Assert-True([bool]$Condition, [string]$Description) {
    if (-not $Condition) { throw "FAIL: $Description" }
    $script:Passed++
    Write-Output "PASS: $Description"
}

function Wait-Server([string]$Url) {
    for ($i=0; $i -lt 30; $i++) {
        try { $null = Read-Response $Url; return } catch { Start-Sleep -Milliseconds 200 }
    }
    throw "Сервер не запустился: $Url"
}

try {
    try { $null = Read-Response 'http://127.0.0.1:5050/notes' }
    catch {
        $normalProcess = Start-Process -FilePath $apiExecutable -WorkingDirectory (Split-Path $apiExecutable) -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $runtimeDirectory 'api.log') -RedirectStandardError (Join-Path $runtimeDirectory 'api-errors.log')
    }
    Wait-Server 'http://127.0.0.1:5050/notes'
    $response = Read-Response 'http://127.0.0.1:5050/notes'
    Assert-True ($response.Code -eq 200) 'GET /notes возвращает 200'
    Assert-True ($response.ContentType -match 'application/json') 'Ответ имеет Content-Type application/json'
    $notes = ConvertFrom-Json -InputObject $response.Body
    Assert-True ($notes.Count -ge 5) 'Получены пять тестовых заметок'
    foreach ($note in $notes) {
        $keys = @($note.PSObject.Properties.Name | Sort-Object)
        Assert-True (($keys -join ',') -eq 'content,formatted_date,id,title_user') "Заметка $($note.id): четыре обязательных поля"
        Assert-True ($note.id -is [int] -or $note.id -is [long]) "Заметка $($note.id): id является числом"
        Assert-True ($note.title_user -match ' - ') "Заметка $($note.id): заголовок объединён с логином"
        $date = [datetime]::MinValue
        Assert-True ([datetime]::TryParseExact($note.formatted_date, 'dd.MM.yyyy', [System.Globalization.CultureInfo]::InvariantCulture, [System.Globalization.DateTimeStyles]::None, [ref]$date)) "Заметка $($note.id): дата ДД.ММ.ГГГГ"
    }
    Assert-True ($notes[0].title_user -eq 'Конференция ИТ - user25') 'Первый заголовок точно соответствует преобразованию'
    Assert-True ($notes[0].content -eq 'Содержимое заметки') 'Содержание возвращено без изменения'
    Assert-True ($notes[0].formatted_date -eq '15.03.2027') 'Дата первой заметки преобразована правильно'
    $filtered = Read-Response 'http://127.0.0.1:5050/notes?user_id=2'
    $filteredNotes = ConvertFrom-Json -InputObject $filtered.Body
    Assert-True ($filtered.Code -eq 200 -and $filteredNotes.Count -eq 2) 'Фильтр user_id работает'
    $empty = Read-Response 'http://127.0.0.1:5050/notes?user_id=2147483647'
    Assert-True ($empty.Code -eq 200 -and $empty.Body.Trim() -eq '[]') 'Нет данных: статус 200 и пустой массив'
    foreach ($query in @('user_id=abc', 'user_id=-1', 'user_id=', 'user_id=2&user_id=3', 'unknown=1')) {
        $bad = Read-Response "http://127.0.0.1:5050/notes?$query"
        Assert-True ($bad.Code -eq 400 -and ($bad.Body | ConvertFrom-Json).error) "Неверный параметр $query возвращает 400 и JSON-ошибку"
    }

    $env:DEMO_DB_CONNECTION = 'Host=127.0.0.1;Port=1;Database=demo_exam_2027;Username=postgres;Password=admin;Timeout=1;Pooling=false'
    $errorProcess = Start-Process -FilePath $apiExecutable -ArgumentList '--urls', 'http://127.0.0.1:5051' -WorkingDirectory (Split-Path $apiExecutable) -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $runtimeDirectory 'error-api.log') -RedirectStandardError (Join-Path $runtimeDirectory 'error-api-errors.log')
    if ($null -eq $oldConnection) { Remove-Item Env:\DEMO_DB_CONNECTION } else { $env:DEMO_DB_CONNECTION = $oldConnection }
    Wait-Server 'http://127.0.0.1:5051/notes'
    $errorResponse = Read-Response 'http://127.0.0.1:5051/notes'
    Assert-True ($errorResponse.Code -eq 500) 'Реальный сбой подключения к БД возвращает 500'
    Assert-True (($errorResponse.Body | ConvertFrom-Json).error -is [string]) 'Ответ 500 содержит JSON с сообщением об ошибке'
    Assert-True ($errorResponse.ContentType -match 'application/json') 'Ответ 500 имеет тип application/json'
    $restored = Read-Response 'http://127.0.0.1:5050/notes'
    Assert-True ($restored.Code -eq 200) 'Основной API продолжает работать после проверки 500'
    Write-Output "Успешно: $script:Passed проверок API."
}
finally {
    foreach ($process in @($normalProcess, $errorProcess)) {
        if ($null -ne $process -and -not $process.HasExited) { Stop-Process -Id $process.Id }
    }
    if ($null -eq $oldConnection) { Remove-Item Env:\DEMO_DB_CONNECTION -ErrorAction SilentlyContinue }
    else { $env:DEMO_DB_CONNECTION = $oldConnection }
}
