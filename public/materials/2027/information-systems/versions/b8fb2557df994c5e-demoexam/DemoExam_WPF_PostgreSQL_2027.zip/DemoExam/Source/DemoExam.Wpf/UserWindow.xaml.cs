using System.Windows;
using DemoExam.Core;

namespace DemoExam.Wpf;

public partial class UserWindow : Window
{
    private readonly User currentUser;
    public UserWindow(User user)
    {
        InitializeComponent(); currentUser = user;
        UserLoginText.Text = "Вы вошли как " + user.Login;
    }

    private async Task RefreshAsync()
    {
        var notes = await Database.GetNotesAsync(currentUser.Id);
        NotesGrid.ItemsSource = notes;
        NotesStatusText.Text = notes.Count == 0 ? "У вас пока нет заметок." : $"Всего заметок: {notes.Count}";
    }

    private async void UserWindow_Loaded(object sender, RoutedEventArgs e)
    {
        try { await RefreshAsync(); } catch (Exception ex) { UiMessages.Error(ex); }
    }

    private async void RefreshButton_Click(object sender, RoutedEventArgs e)
    {
        try { await RefreshAsync(); } catch (Exception ex) { UiMessages.Error(ex); }
    }

    private void LogoutButton_Click(object sender, RoutedEventArgs e) => Close();
}
