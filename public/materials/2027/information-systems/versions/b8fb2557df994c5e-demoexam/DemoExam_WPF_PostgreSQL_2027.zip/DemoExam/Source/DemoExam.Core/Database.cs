using System.Text.Json;
using Npgsql;

namespace DemoExam.Core;

// Все обращения к PostgreSQL собраны в одном понятном классе.
public static class Database
{
    public const string BlockedMessage = "Вы заблокированы. Обратитесь к администратору";
    public const string InvalidMessage = "Вы ввели неверный логин или пароль. Пожалуйста проверьте ещё раз введенные данные";

    public static string ConnectionString { get; set; } = LoadConnectionString();

    private static string LoadConnectionString()
    {
        string? value = Environment.GetEnvironmentVariable("DEMO_DB_CONNECTION");
        if (!string.IsNullOrWhiteSpace(value)) return value;
        string path = Path.Combine(AppContext.BaseDirectory, "appsettings.json");
        if (!File.Exists(path)) throw new FileNotFoundException("Рядом с программой отсутствует appsettings.json.");
        using var json = JsonDocument.Parse(File.ReadAllText(path));
        return json.RootElement.GetProperty("ConnectionStrings").GetProperty("Database").GetString()!;
    }

    public static async Task<NpgsqlConnection> OpenAsync()
    {
        var connection = new NpgsqlConnection(ConnectionString);
        try { await connection.OpenAsync(); return connection; }
        catch { await connection.DisposeAsync(); throw; }
    }

    public static async Task<LoginResult> LoginAsync(string login, string password, bool puzzleSolved)
    {
        login = login.Trim();
        if (login.Length == 0 || password.Length == 0)
            return new(false, "Заполните поля «Логин» и «Пароль».");

        await using var connection = await OpenAsync();
        await using var transaction = await connection.BeginTransactionAsync();
        // Блокировка строки не даёт двум одновременным входам потерять счётчик ошибок.
        await using var select = new NpgsqlCommand("""
            SELECT id, login, role, is_blocked, failed_attempts, password_hash
            FROM users WHERE lower(login) = lower(@login) FOR UPDATE
            """, connection, transaction);
        select.Parameters.AddWithValue("login", login);
        User user;
        string hash;
        await using (var reader = await select.ExecuteReaderAsync())
        {
            if (!await reader.ReadAsync()) return new(false, InvalidMessage);
            user = new User { Id = reader.GetInt32(0), Login = reader.GetString(1), Role = reader.GetString(2),
                IsBlocked = reader.GetBoolean(3), FailedAttempts = reader.GetInt32(4) };
            hash = reader.GetString(5);
        }
        if (user.IsBlocked) return new(false, BlockedMessage);

        bool passwordCorrect = PasswordHelper.Verify(password, hash);
        bool success = passwordCorrect && puzzleSolved;
        int attempts = success ? 0 : Math.Min(user.FailedAttempts + 1, 3);
        bool blocked = attempts >= 3;
        await using var update = new NpgsqlCommand("""
            UPDATE users SET failed_attempts = @attempts, is_blocked = @blocked WHERE id = @id
            """, connection, transaction);
        update.Parameters.AddWithValue("attempts", attempts);
        update.Parameters.AddWithValue("blocked", blocked);
        update.Parameters.AddWithValue("id", user.Id);
        await update.ExecuteNonQueryAsync();
        await transaction.CommitAsync();
        if (success) { user.FailedAttempts = 0; return new(true, "Вы успешно авторизовались", user); }
        if (blocked) return new(false, BlockedMessage);
        return new(false, passwordCorrect
            ? "Пазл собран неверно. Поменяйте фрагменты местами и повторите вход."
            : InvalidMessage);
    }

    private static async Task RequireAdminAsync(NpgsqlConnection connection, NpgsqlTransaction transaction, int actorId)
    {
        await using var command = new NpgsqlCommand("""
            SELECT COUNT(*) FROM users WHERE id = @id AND role = 'Администратор' AND NOT is_blocked
            """, connection, transaction);
        command.Parameters.AddWithValue("id", actorId);
        if (Convert.ToInt64(await command.ExecuteScalarAsync()) != 1)
            throw new InvalidOperationException("Изменять пользователей может только действующий администратор.");
    }

    public static async Task<List<User>> GetUsersAsync(int actorId, string search = "")
    {
        await using var connection = await OpenAsync();
        await using var transaction = await connection.BeginTransactionAsync();
        await RequireAdminAsync(connection, transaction, actorId);
        await using var command = new NpgsqlCommand("""
            SELECT id, login, role, is_blocked, failed_attempts FROM users
            WHERE position(lower(@search) in lower(login)) > 0 ORDER BY id
            """, connection, transaction);
        command.Parameters.AddWithValue("search", search.Trim());
        var users = new List<User>();
        await using var reader = await command.ExecuteReaderAsync();
        while (await reader.ReadAsync())
            users.Add(new User { Id = reader.GetInt32(0), Login = reader.GetString(1), Role = reader.GetString(2),
                IsBlocked = reader.GetBoolean(3), FailedAttempts = reader.GetInt32(4) });
        return users;
    }

    public static async Task SaveUserAsync(int actorId, User user, string newPassword)
    {
        user.Login = user.Login.Trim();
        if (user.Login.Length == 0 || user.Login.Length > 100)
            throw new InvalidOperationException("Логин должен содержать от 1 до 100 символов.");
        if (user.Role != "Администратор" && user.Role != "Пользователь")
            throw new InvalidOperationException("Выберите роль пользователя.");
        if (user.Id == 0 && newPassword.Length == 0)
            throw new InvalidOperationException("Для нового пользователя укажите пароль.");
        if (user.Id == actorId && (user.IsBlocked || user.Role != "Администратор"))
            throw new InvalidOperationException("Нельзя заблокировать себя или снять свою роль администратора.");

        await using var connection = await OpenAsync();
        await using var transaction = await connection.BeginTransactionAsync();
        await RequireAdminAsync(connection, transaction, actorId);
        await using var duplicate = new NpgsqlCommand("""
            SELECT COUNT(*) FROM users WHERE lower(login) = lower(@login) AND id <> @id
            """, connection, transaction);
        duplicate.Parameters.AddWithValue("login", user.Login);
        duplicate.Parameters.AddWithValue("id", user.Id);
        if (Convert.ToInt64(await duplicate.ExecuteScalarAsync()) > 0)
            throw new InvalidOperationException("Пользователь с указанным логином уже существует. Введите другой логин.");

        string sql = user.Id == 0
            ? "INSERT INTO users (login, password_hash, role, is_blocked, failed_attempts) VALUES (@login, @hash, @role, @blocked, @attempts)"
            : """
              UPDATE users SET login = @login, role = @role, is_blocked = @blocked,
                  failed_attempts = @attempts,
                  password_hash = CASE WHEN @hash = '' THEN password_hash ELSE @hash END
              WHERE id = @id
              """;
        await using var command = new NpgsqlCommand(sql, connection, transaction);
        command.Parameters.AddWithValue("id", user.Id);
        command.Parameters.AddWithValue("login", user.Login);
        command.Parameters.AddWithValue("hash", newPassword.Length == 0 ? "" : PasswordHelper.Hash(newPassword));
        command.Parameters.AddWithValue("role", user.Role);
        command.Parameters.AddWithValue("blocked", user.IsBlocked);
        // При снятии блокировки начинается новая последовательность попыток.
        command.Parameters.AddWithValue("attempts", user.IsBlocked ? 3 : 0);
        try
        {
            if (await command.ExecuteNonQueryAsync() != 1)
                throw new InvalidOperationException("Пользователь не найден. Обновите список.");
            await transaction.CommitAsync();
        }
        catch (PostgresException e) when (e.SqlState == PostgresErrorCodes.UniqueViolation)
        {
            throw new InvalidOperationException("Пользователь с указанным логином уже существует. Введите другой логин.");
        }
    }

    public static async Task<List<Note>> GetNotesAsync(int userId)
    {
        await using var connection = await OpenAsync();
        await using var command = new NpgsqlCommand("SELECT id, title, content, created_at FROM notes WHERE id_user = @id ORDER BY id", connection);
        command.Parameters.AddWithValue("id", userId);
        var notes = new List<Note>();
        await using var reader = await command.ExecuteReaderAsync();
        while (await reader.ReadAsync()) notes.Add(new Note { Id = reader.GetInt32(0), Title = reader.GetString(1),
            Content = reader.GetString(2), CreatedAt = reader.GetDateTime(3) });
        return notes;
    }

    public static async Task<List<OrderCost>> GetOrderCostsAsync()
    {
        await using var connection = await OpenAsync();
        await using var command = new NpgsqlCommand("SELECT number, customer, materials_cost, operations_cost, total_cost, sale_total FROM order_costs ORDER BY order_id", connection);
        var orders = new List<OrderCost>();
        await using var reader = await command.ExecuteReaderAsync();
        while (await reader.ReadAsync()) orders.Add(new OrderCost { Number = reader.GetString(0), Customer = reader.GetString(1),
            MaterialsCost = reader.GetDecimal(2), OperationsCost = reader.GetDecimal(3), TotalCost = reader.GetDecimal(4), SaleTotal = reader.GetDecimal(5) });
        return orders;
    }
}
