﻿$ErrorActionPreference = 'Stop'
$apiDirectory = Join-Path (Split-Path $PSScriptRoot -Parent) 'Api'
$oldConnection = $env:DEMO_DB_CONNECTION
try {
    # Только этот процесс API использует недоступный порт БД. Рабочий сервер не меняется.
    $env:DEMO_DB_CONNECTION = 'Host=127.0.0.1;Port=1;Database=demo_exam_2027;Username=postgres;Password=admin;Timeout=1;Pooling=false'
    & (Join-Path $apiDirectory 'DemoExam.Api.exe') --urls http://127.0.0.1:5051
}
finally {
    if ($null -eq $oldConnection) { Remove-Item Env:\DEMO_DB_CONNECTION -ErrorAction SilentlyContinue }
    else { $env:DEMO_DB_CONNECTION = $oldConnection }
}
