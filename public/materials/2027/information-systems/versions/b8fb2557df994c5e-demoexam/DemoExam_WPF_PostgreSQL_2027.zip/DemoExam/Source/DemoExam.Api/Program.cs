using System.Globalization;
using DemoExam.Core;
using Npgsql;

var builder = WebApplication.CreateBuilder(new WebApplicationOptions { Args = args, ContentRootPath = AppContext.BaseDirectory });
// Для локального запуска достаточно консоли. Журнал Windows может требовать права администратора.
builder.Logging.ClearProviders();
builder.Logging.AddConsole();
var app = builder.Build();

// В том числе непредвиденные ошибки превращаются в JSON, а не в HTML-страницу.
app.Use(async (context, next) =>
{
    try { await next(context); }
    catch (Exception ex)
    {
        app.Logger.LogError(ex, "Ошибка обработки запроса");
        context.Response.StatusCode = 500;
        await context.Response.WriteAsJsonAsync(new { error = "Внутренняя ошибка сервера" });
    }
});

app.MapGet("/notes", async (HttpRequest request) =>
{
    // Необязательный фильтр позволяет проверить и пустой результат, и неверный тип.
    int? userId = null;
    foreach (var key in request.Query.Keys)
        if (key != "user_id") return Results.Json(new { error = "Неизвестный параметр: " + key }, statusCode: 400);
    if (request.Query.ContainsKey("user_id"))
    {
        var values = request.Query["user_id"];
        if (values.Count != 1 || !int.TryParse(values[0], out int parsed) || parsed <= 0)
            return Results.Json(new { error = "Параметр user_id должен быть положительным целым числом" }, statusCode: 400);
        userId = parsed;
    }

    try
    {
        await using var connection = await Database.OpenAsync();
        await using var command = new NpgsqlCommand("""
            SELECT n.id, n.title, u.login, n.content, n.created_at
            FROM notes n JOIN users u ON u.id = n.id_user
            WHERE (@user_id IS NULL OR n.id_user = @user_id)
            ORDER BY n.id
            """, connection);
        command.Parameters.AddWithValue("user_id", NpgsqlTypes.NpgsqlDbType.Integer, (object?)userId ?? DBNull.Value);
        var result = new List<object>();
        await using var reader = await command.ExecuteReaderAsync();
        while (await reader.ReadAsync())
            result.Add(new { id = reader.GetInt32(0), title_user = reader.GetString(1) + " - " + reader.GetString(2),
                content = reader.GetString(3), formatted_date = reader.GetDateTime(4).ToString("dd.MM.yyyy", CultureInfo.InvariantCulture) });
        return Results.Json(result);
    }
    catch (Exception ex)
    {
        app.Logger.LogError(ex, "Не удалось получить заметки из PostgreSQL");
        return Results.Json(new { error = "Ошибка получения данных из базы данных" }, statusCode: 500);
    }
});

app.Run();

// Класс виден проекту проверок.
public partial class Program { }
