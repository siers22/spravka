@echo off
cd /d "%~dp0Api"
DemoExam.Api.exe
pause
