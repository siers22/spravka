﻿param([string]$NuGetConfig = '')
$ErrorActionPreference = 'Stop'
$root = Split-Path $PSScriptRoot -Parent
$psql = 'C:\Program Files\PostgreSQL\18\bin\psql.exe'
if (-not (Test-Path -LiteralPath $psql)) { $psql = (Get-Command psql -ErrorAction Stop).Source }
$testName = 'shoe_shop_check_' + [Guid]::NewGuid().ToString('N')
$oldPassword = $env:PGPASSWORD
$env:PGPASSWORD = 'admin'
$env:PGCLIENTENCODING = 'UTF8'
$created = $false
try {
    & $psql -h 127.0.0.1 -U postgres -d postgres -w -v ON_ERROR_STOP=1 -c "CREATE DATABASE $testName ENCODING 'UTF8';"
    if ($LASTEXITCODE -ne 0) { throw 'Не удалось создать отдельную тестовую базу.' }
    $created = $true
    foreach ($file in @('01_schema.sql', '02_data.sql')) {
        & $psql -h 127.0.0.1 -U postgres -d $testName -w -v ON_ERROR_STOP=1 -f (Join-Path $root "Database\$file")
        if ($LASTEXITCODE -ne 0) { throw "Ошибка импорта тестовой базы: $file." }
    }
    $project = Join-Path $PSScriptRoot 'Checks\Checks.csproj'
    $restoreArgs = @('restore', $project, '--ignore-failed-sources', '-p:NuGetAudit=false')
    if ($NuGetConfig) { $restoreArgs += @('--configfile', (Resolve-Path -LiteralPath $NuGetConfig).Path) }
    & dotnet @restoreArgs
    if ($LASTEXITCODE -ne 0) { throw 'Ошибка восстановления тестового проекта.' }
    & dotnet build $project -c Release --no-restore -p:UseSharedCompilation=false
    if ($LASTEXITCODE -ne 0) { throw 'Ошибка сборки проверок.' }
    & dotnet run --project $project -c Release --no-build -- $testName | Tee-Object -FilePath (Join-Path $PSScriptRoot 'Results.txt')
    if ($LASTEXITCODE -ne 0) { throw 'Проверки обнаружили ошибки. Смотрите Results.txt.' }
}
finally {
    if ($created) {
        & $psql -h 127.0.0.1 -U postgres -d postgres -w -v ON_ERROR_STOP=1 -c "DROP DATABASE $testName WITH (FORCE);"
    }
    if ($null -eq $oldPassword) { Remove-Item Env:\PGPASSWORD -ErrorAction SilentlyContinue }
    else { $env:PGPASSWORD = $oldPassword }
}
