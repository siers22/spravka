using System.Globalization;
using System.IO;

namespace ShoeShop;

public class User
{
    public int Id { get; set; }
    public string Login { get; set; } = "";
    public string FullName { get; set; } = "";
    public int RoleId { get; set; }
    public bool IsAdmin => RoleId == 1;
    public bool IsStaff => RoleId == 1 || RoleId == 2;
}

public class Product
{
    public int Id { get; set; }
    public int CategoryId { get; set; }
    public string Category { get; set; } = "";
    public string Subcategory { get; set; } = "";
    public string Name { get; set; } = "";
    public string Manufacturer { get; set; } = "";
    public string Description { get; set; } = "";
    public string Composition { get; set; } = "";
    public string ImageName { get; set; } = "";
    public decimal Price { get; set; }
    public int Discount { get; set; }
    public int Quantity { get; set; }
    public decimal FinalPrice => CalculatePrice(Price, Discount);
    public string PriceText => FinalPrice.ToString("N2", CultureInfo.GetCultureInfo("ru-RU")) + " ₽";
    public string DiscountText => Discount == 0 ? "Без скидки" : "Скидка 25%";
    public string StockText => Quantity > 5 ? "много" : "мало";
    public string CardBackground => Quantity <= 3 ? "#ff8080" : "#FFFFFF";
    public string ImagePath => GetImagePath(ImageName);

    public static decimal CalculatePrice(decimal price, int discount)
    {
        return Math.Round(price * (100 - discount) / 100m, 2, MidpointRounding.AwayFromZero);
    }

    public static string GetImagePath(string imageName)
    {
        string image = Path.Combine(AppContext.BaseDirectory, "Assets", "Images", Path.GetFileName(imageName));
        if (File.Exists(image))
            return image;
        return Path.Combine(AppContext.BaseDirectory, "Assets", "picture.png");
    }
}

public class SizeOption
{
    public int StockId { get; set; }
    public decimal Size { get; set; }
    public int Available { get; set; }
    public string Display => $"{Size:0.#} — доступно {Available} пар";
}

public class CartLine
{
    public int StockId { get; set; }
    public string Name { get; set; } = "";
    public string Manufacturer { get; set; } = "";
    public decimal Size { get; set; }
    public int Quantity { get; set; }
    public decimal UnitPrice { get; set; }
    public decimal Total => UnitPrice * Quantity;
}

public class Order
{
    public int Id { get; set; }
    public DateTime Date { get; set; }
    public int UserId { get; set; }
    public string FullName { get; set; } = "";
    public decimal Total { get; set; }
}

public class Category
{
    public int Id { get; set; }
    public string Name { get; set; } = "";
}
