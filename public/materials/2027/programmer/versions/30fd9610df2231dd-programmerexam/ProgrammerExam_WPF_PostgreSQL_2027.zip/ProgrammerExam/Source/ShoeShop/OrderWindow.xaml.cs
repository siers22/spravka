using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace ShoeShop;

public partial class OrderWindow : Window
{
    private readonly User user;
    private readonly Order? order;
    private readonly bool editable;
    public List<CartLine> Lines { get; private set; }
    public bool Saved { get; private set; }

    public OrderWindow(User actor, List<CartLine>? draft = null, Order? existingOrder = null)
    {
        InitializeComponent();
        user = actor;
        order = existingOrder;
        editable = order == null || user.IsAdmin;
        Lines = draft?.ToList() ?? new List<CartLine>();
        UserNameText.Text = user.FullName;
        if (order != null)
        {
            Title = $"Чудо Обувь — заказ №{order.Id}";
            HeadingText.Text = user.IsAdmin ? $"Редактирование заказа №{order.Id}" : $"Состав заказа №{order.Id}";
            SaveButton.Content = "Сохранить изменения";
            CancelOrderButton.Visibility = Visibility.Collapsed;
            HintText.Text = user.IsAdmin ? "Цены существующих позиций сохраняются. Удалённые пары вернутся в остаток." : "Редактировать сохранённый заказ может администратор.";
        }
        EditPanel.Visibility = editable ? Visibility.Visible : Visibility.Collapsed;
        SaveButton.Visibility = editable ? Visibility.Visible : Visibility.Collapsed;
        CustomerBox.IsEnabled = order == null && user.IsStaff;
        DateBox.IsEnabled = order != null && user.IsAdmin;
        DateBox.SelectedDate = DateTime.Today;
        DateBox.PreviewTextInput += (sender, args) =>
        {
            if (args.Text.Any(c => !char.IsDigit(c) && c != '.'))
            {
                args.Handled = true;
                Ui.Info("Введите дату в формате ДД.ММ.ГГГГ или выберите её в календаре.");
            }
        };
        DateBox.DateValidationError += (sender, args) =>
        {
            args.ThrowException = false;
            Ui.Info("Указана неверная дата. Выберите дату в календаре.");
            DateBox.SelectedDate = order?.Date ?? DateTime.Today;
        };
        Loaded += (sender, args) => LoadOrder();
    }

    private void LoadOrder()
    {
        try
        {
            CustomerBox.ItemsSource = user.IsStaff ? Db.GetUsers() : new List<User> { user };
            if (order != null)
            {
                Order current = Db.GetOrders(user).First(o => o.Id == order.Id);
                CustomerBox.SelectedValue = current.UserId;
                DateBox.SelectedDate = current.Date;
                Lines = Db.GetOrderLines(user, order.Id);
            }
            else
                CustomerBox.SelectedValue = user.Id;
            RefreshLines();
        }
        catch (Exception error)
        {
            SaveButton.IsEnabled = false;
            Ui.Error(error);
        }
    }

    private void RefreshLines()
    {
        LinesGrid.ItemsSource = null;
        LinesGrid.ItemsSource = Lines;
        TotalText.Text = $"Итого: {Lines.Sum(l => l.Total):N2} ₽";
    }

    private void Add_Click(object sender, RoutedEventArgs e)
    {
        MainWindow picker = new MainWindow(user, true);
        picker.Owner = this;
        if (picker.ShowDialog() != true || picker.SelectedLine == null)
            return;
        CartLine line = picker.SelectedLine;
        CartLine? existing = Lines.FirstOrDefault(l => l.StockId == line.StockId);
        int available;
        try
        {
            available = Db.GetAvailableStock(line.StockId, order?.Id);
        }
        catch (Exception error)
        {
            Ui.Error(error);
            return;
        }
        if ((long)line.Quantity + (existing?.Quantity ?? 0) > available)
        {
            Ui.Info($"С учётом заказа доступно только {available} пар этого размера. Уменьшите количество.");
            return;
        }
        if (existing == null)
            Lines.Add(line);
        else
        {
            if ((long)existing.Quantity + line.Quantity > int.MaxValue)
            {
                Ui.Info("Количество слишком большое. Уменьшите его.");
                return;
            }
            existing.Quantity += line.Quantity;
        }
        RefreshLines();
    }

    private void Remove_Click(object sender, RoutedEventArgs e)
    {
        if (LinesGrid.SelectedItem is not CartLine line)
        {
            Ui.Info("Выберите позицию в таблице для удаления.");
            return;
        }
        if (!Ui.Confirm($"Удалить из заказа «{line.Name}», размер {line.Size:0.#}?"))
            return;
        Lines.Remove(line);
        RefreshLines();
    }

    private void Quantity_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            if (LinesGrid.SelectedItem is not CartLine line)
                throw new InvalidOperationException("Выберите позицию, количество которой нужно изменить.");
            int quantity = Ui.ReadQuantity(QuantityBox);
            int available = Db.GetAvailableStock(line.StockId, order?.Id);
            if (quantity > available)
                throw new InvalidOperationException($"Доступно только {available} пар этого размера. Уменьшите количество.");
            line.Quantity = quantity;
            RefreshLines();
        }
        catch (Exception error)
        {
            Ui.Error(error);
        }
    }

    private void Save_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            if (CustomerBox.SelectedItem is not User customer)
                throw new InvalidOperationException("Выберите клиента из списка.");
            if (DateBox.SelectedDate == null)
                throw new InvalidOperationException("Выберите корректную дату заказа.");
            if (Lines.Count == 0)
                throw new InvalidOperationException("Заказ пуст. Добавьте товар через кнопку «Добавить товар».");
            if (!Ui.Confirm(order == null ? "Подтвердить заказ? Выбранные пары будут списаны из доступного остатка." : "Сохранить изменения заказа и пересчитать остатки?"))
                return;
            int id = Db.SaveOrder(user, customer.Id, DateBox.SelectedDate.Value, Lines, order?.Id);
            Saved = true;
            Ui.Info($"Заказ №{id} сохранён. Остатки товаров обновлены.");
            DialogResult = true;
        }
        catch (Exception error)
        {
            Ui.Error(error);
        }
    }

    private void CancelOrder_Click(object sender, RoutedEventArgs e)
    {
        if (Lines.Count > 0 && !Ui.Confirm("Очистить корзину и отказаться от оформления заказа?"))
            return;
        Lines.Clear();
        Close();
    }

    private void Back_Click(object sender, RoutedEventArgs e)
    {
        if (order != null && editable && !Ui.Confirm("Закрыть заказ без сохранения изменений?"))
            return;
        Close();
    }

    private void Line_Changed(object sender, SelectionChangedEventArgs e)
    {
        if (LinesGrid.SelectedItem is CartLine line)
            QuantityBox.Text = line.Quantity.ToString();
    }

    private void Quantity_Input(object sender, TextCompositionEventArgs e)
    {
        Ui.DigitsOnly(sender, e);
    }

    private void Quantity_Paste(object sender, DataObjectPastingEventArgs e)
    {
        Ui.CheckPaste(sender, e);
    }
}
