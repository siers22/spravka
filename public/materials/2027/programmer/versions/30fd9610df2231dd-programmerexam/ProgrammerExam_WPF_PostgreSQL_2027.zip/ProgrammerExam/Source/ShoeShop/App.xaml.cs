using System.Globalization;
using System.Windows;

namespace ShoeShop;

public partial class App : Application
{
    protected override void OnStartup(StartupEventArgs e)
    {
        CultureInfo culture = CultureInfo.GetCultureInfo("ru-RU");
        CultureInfo.DefaultThreadCurrentCulture = culture;
        CultureInfo.DefaultThreadCurrentUICulture = culture;
        DispatcherUnhandledException += (sender, args) =>
        {
            args.Handled = true;
            Ui.Error(args.Exception);
        };
        base.OnStartup(e);
    }
}
