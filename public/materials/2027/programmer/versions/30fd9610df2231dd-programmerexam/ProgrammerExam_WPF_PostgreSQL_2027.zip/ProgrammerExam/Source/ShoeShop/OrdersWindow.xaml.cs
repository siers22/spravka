using System.Windows;
using System.Windows.Input;

namespace ShoeShop;

public partial class OrdersWindow : Window
{
    private readonly User user;

    public OrdersWindow(User actor)
    {
        InitializeComponent();
        user = actor;
        UserNameText.Text = user.FullName;
        if (user.IsAdmin)
            OpenButton.Content = "Просмотреть / изменить";
        Loaded += (sender, args) => LoadOrders();
    }

    private void LoadOrders()
    {
        try
        {
            OrdersGrid.ItemsSource = Db.GetOrders(user);
        }
        catch (Exception error)
        {
            Ui.Error(error);
        }
    }

    private void Add_Click(object sender, RoutedEventArgs e)
    {
        OrderWindow window = new OrderWindow(user);
        window.Owner = this;
        window.ShowDialog();
        LoadOrders();
    }

    private void Open_Click(object sender, RoutedEventArgs e)
    {
        if (OrdersGrid.SelectedItem is not Order order)
        {
            Ui.Info("Выберите заказ в таблице.");
            return;
        }
        OrderWindow window = new OrderWindow(user, existingOrder: order);
        window.Owner = this;
        window.ShowDialog();
        LoadOrders();
    }

    private void Delete_Click(object sender, RoutedEventArgs e)
    {
        if (OrdersGrid.SelectedItem is not Order order)
        {
            Ui.Info("Выберите заказ для удаления.");
            return;
        }
        if (!Ui.Confirm($"Удалить заказ №{order.Id}? Все его позиции будут удалены, а пары вернутся в доступный остаток."))
            return;
        try
        {
            Db.DeleteOrder(user, order.Id);
            LoadOrders();
            Ui.Info("Заказ удалён. Остатки товаров обновлены.");
        }
        catch (Exception error)
        {
            Ui.Error(error);
        }
    }

    private void Refresh_Click(object sender, RoutedEventArgs e)
    {
        LoadOrders();
    }

    private void Back_Click(object sender, RoutedEventArgs e)
    {
        Close();
    }

    private void Order_DoubleClick(object sender, MouseButtonEventArgs e)
    {
        if (OrdersGrid.SelectedItem != null)
            Open_Click(sender, e);
    }
}
