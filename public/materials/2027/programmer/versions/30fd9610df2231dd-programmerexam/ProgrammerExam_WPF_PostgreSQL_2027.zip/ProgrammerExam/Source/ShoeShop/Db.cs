using System.IO;
using System.Text.Json;
using Npgsql;

namespace ShoeShop;

public static class Db
{
    public static string ConnectionString { get; set; } = LoadConnectionString();

    private static string LoadConnectionString()
    {
        using JsonDocument config = JsonDocument.Parse(File.ReadAllText(Path.Combine(AppContext.BaseDirectory, "database.json")));
        return config.RootElement.GetProperty("ConnectionString").GetString()!;
    }

    private static NpgsqlConnection OpenConnection()
    {
        NpgsqlConnection connection = new NpgsqlConnection(ConnectionString);
        try
        {
            connection.Open();
            return connection;
        }
        catch
        {
            connection.Dispose();
            throw;
        }
    }

    private static NpgsqlCommand Command(NpgsqlConnection connection, string sql, params object[] values)
    {
        NpgsqlCommand command = new NpgsqlCommand(sql, connection);
        for (int i = 0; i < values.Length; i++)
            command.Parameters.AddWithValue("p" + i, values[i]);
        return command;
    }

    private static User ReadUser(NpgsqlDataReader reader)
    {
        return new User
        {
            Id = reader.GetInt32(0),
            Login = reader.GetString(1),
            FullName = reader.GetString(2),
            RoleId = reader.GetInt32(3)
        };
    }

    public static User? Login(string login)
    {
        using NpgsqlConnection connection = OpenConnection();
        using NpgsqlCommand command = Command(connection,
            "SELECT id, login, last_name || ' ' || first_name || ' ' || middle_name, role_id FROM users WHERE login = @p0", login.Trim());
        using NpgsqlDataReader reader = command.ExecuteReader();
        return reader.Read() ? ReadUser(reader) : null;
    }

    public static List<User> GetUsers()
    {
        using NpgsqlConnection connection = OpenConnection();
        using NpgsqlCommand command = Command(connection,
            "SELECT id, login, last_name || ' ' || first_name || ' ' || middle_name, role_id FROM users ORDER BY last_name, first_name");
        using NpgsqlDataReader reader = command.ExecuteReader();
        List<User> users = new List<User>();
        while (reader.Read())
            users.Add(ReadUser(reader));
        return users;
    }

    public static List<Category> GetCategories()
    {
        using NpgsqlConnection connection = OpenConnection();
        using NpgsqlCommand command = Command(connection, "SELECT id, name FROM categories ORDER BY name");
        using NpgsqlDataReader reader = command.ExecuteReader();
        List<Category> categories = new List<Category> { new Category { Id = 0, Name = "Все категории" } };
        while (reader.Read())
            categories.Add(new Category { Id = reader.GetInt32(0), Name = reader.GetString(1) });
        return categories;
    }

    public static List<Product> GetProducts(DateTime? calculationDate = null)
    {
        using NpgsqlConnection connection = OpenConnection();
        return ReadProducts(connection, calculationDate ?? DateTime.Today);
    }

    private static List<Product> ReadProducts(NpgsqlConnection connection, DateTime calculationDate)
    {
        DateTime monthEnd = new DateTime(calculationDate.Year, calculationDate.Month, 1);
        DateTime monthStart = monthEnd.AddMonths(-1);
        // Границы календарного месяца корректны и при переходе с января на декабрь.
        string sql = """
            SELECT p.id, c.id, c.name, sc.name, p.name, m.name, p.description, p.composition,
                   COALESCE(p.image_name, ''), p.price,
                   COALESCE((SELECT SUM(quantity) FROM stock_items WHERE product_id = p.id), 0)::integer,
                   CASE WHEN EXISTS (
                       SELECT 1 FROM order_items oi
                       JOIN stock_items si ON si.id = oi.stock_item_id
                       JOIN orders o ON o.id = oi.order_id
                       WHERE si.product_id = p.id AND o.order_date >= @p0 AND o.order_date < @p1
                   ) THEN 0 ELSE 25 END
            FROM products p
            JOIN subcategories sc ON sc.id = p.subcategory_id
            JOIN categories c ON c.id = sc.category_id
            JOIN manufacturers m ON m.id = p.manufacturer_id
            ORDER BY p.id
            """;
        using NpgsqlCommand command = Command(connection, sql, DateOnly.FromDateTime(monthStart), DateOnly.FromDateTime(monthEnd));
        using NpgsqlDataReader reader = command.ExecuteReader();
        List<Product> products = new List<Product>();
        while (reader.Read())
        {
            products.Add(new Product
            {
                Id = reader.GetInt32(0), CategoryId = reader.GetInt32(1),
                Category = reader.GetString(2), Subcategory = reader.GetString(3),
                Name = reader.GetString(4), Manufacturer = reader.GetString(5),
                Description = reader.GetString(6), Composition = reader.GetString(7),
                ImageName = reader.GetString(8), Price = reader.GetDecimal(9),
                Quantity = reader.GetInt32(10), Discount = reader.GetInt32(11)
            });
        }
        return products;
    }

    public static List<Product> FilterProducts(List<Product> products, string search, int categoryId, int sort)
    {
        IEnumerable<Product> result = products;
        if (categoryId != 0)
            result = result.Where(p => p.CategoryId == categoryId);
        if (!string.IsNullOrWhiteSpace(search))
        {
            string text = search.Trim();
            result = result.Where(p => p.Name.Contains(text, StringComparison.OrdinalIgnoreCase) || p.Description.Contains(text, StringComparison.OrdinalIgnoreCase));
        }
        if (sort == 1)
            result = result.OrderBy(p => p.FinalPrice).ThenBy(p => p.Name);
        if (sort == 2)
            result = result.OrderByDescending(p => p.FinalPrice).ThenBy(p => p.Name);
        return result.ToList();
    }

    public static List<SizeOption> GetSizes(int productId)
    {
        using NpgsqlConnection connection = OpenConnection();
        using NpgsqlCommand command = Command(connection,
            "SELECT si.id, s.value, si.quantity FROM stock_items si JOIN sizes s ON s.id = si.size_id WHERE si.product_id = @p0 ORDER BY s.value", productId);
        using NpgsqlDataReader reader = command.ExecuteReader();
        List<SizeOption> sizes = new List<SizeOption>();
        while (reader.Read())
            sizes.Add(new SizeOption { StockId = reader.GetInt32(0), Size = reader.GetDecimal(1), Available = reader.GetInt32(2) });
        return sizes;
    }

    public static int GetAvailableStock(int stockId, int? orderId = null)
    {
        using NpgsqlConnection connection = OpenConnection();
        using NpgsqlCommand command = Command(connection, "SELECT quantity FROM stock_items WHERE id = @p0", stockId);
        object? result = command.ExecuteScalar();
        if (result == null)
            throw new InvalidOperationException("Товарная позиция не найдена. Обновите каталог.");
        int available = (int)result;
        if (orderId.HasValue)
        {
            using NpgsqlCommand reserved = Command(connection, "SELECT quantity FROM order_items WHERE order_id = @p0 AND stock_item_id = @p1", orderId.Value, stockId);
            available += (int?)reserved.ExecuteScalar() ?? 0;
        }
        return available;
    }

    private static User RequireUser(NpgsqlConnection connection, int userId)
    {
        using NpgsqlCommand command = Command(connection,
            "SELECT id, login, last_name || ' ' || first_name || ' ' || middle_name, role_id FROM users WHERE id = @p0", userId);
        using NpgsqlDataReader reader = command.ExecuteReader();
        if (!reader.Read())
            throw new InvalidOperationException("Пользователь не найден. Войдите в систему заново.");
        return ReadUser(reader);
    }

    public static List<Order> GetOrders(User actor)
    {
        using NpgsqlConnection connection = OpenConnection();
        if (!RequireUser(connection, actor.Id).IsStaff)
            throw new InvalidOperationException("Просматривать все заказы могут только менеджер и администратор.");
        using NpgsqlCommand command = Command(connection, """
            SELECT o.id, o.order_date, o.user_id, u.last_name || ' ' || u.first_name || ' ' || u.middle_name,
                   COALESCE(SUM(oi.quantity * oi.unit_price), 0)
            FROM orders o JOIN users u ON u.id = o.user_id
            LEFT JOIN order_items oi ON oi.order_id = o.id
            GROUP BY o.id, u.id ORDER BY o.order_date DESC, o.id DESC
            """);
        using NpgsqlDataReader reader = command.ExecuteReader();
        List<Order> orders = new List<Order>();
        while (reader.Read())
        {
            orders.Add(new Order
            {
                Id = reader.GetInt32(0), Date = reader.GetDateTime(1), UserId = reader.GetInt32(2),
                FullName = reader.GetString(3), Total = reader.GetDecimal(4)
            });
        }
        return orders;
    }

    public static List<CartLine> GetOrderLines(User actor, int orderId)
    {
        using NpgsqlConnection connection = OpenConnection();
        User user = RequireUser(connection, actor.Id);
        using NpgsqlCommand access = Command(connection, "SELECT user_id FROM orders WHERE id = @p0", orderId);
        object? owner = access.ExecuteScalar();
        if (owner == null || (!user.IsStaff && (int)owner != user.Id))
            throw new InvalidOperationException("Заказ не найден или недоступен этому пользователю.");
        return ReadOrderLines(connection, orderId);
    }

    private static List<CartLine> ReadOrderLines(NpgsqlConnection connection, int orderId)
    {
        using NpgsqlCommand command = Command(connection, """
            SELECT si.id, p.name, m.name, s.value, oi.quantity, oi.unit_price
            FROM order_items oi JOIN stock_items si ON si.id = oi.stock_item_id
            JOIN products p ON p.id = si.product_id JOIN manufacturers m ON m.id = p.manufacturer_id
            JOIN sizes s ON s.id = si.size_id WHERE oi.order_id = @p0 ORDER BY oi.id
            """, orderId);
        using NpgsqlDataReader reader = command.ExecuteReader();
        List<CartLine> lines = new List<CartLine>();
        while (reader.Read())
        {
            lines.Add(new CartLine
            {
                StockId = reader.GetInt32(0), Name = reader.GetString(1), Manufacturer = reader.GetString(2),
                Size = reader.GetDecimal(3), Quantity = reader.GetInt32(4), UnitPrice = reader.GetDecimal(5)
            });
        }
        return lines;
    }

    public static int SaveOrder(User actor, int customerId, DateTime date, List<CartLine> lines, int? orderId = null)
    {
        if (lines.Count == 0 || lines.Any(l => l.Quantity <= 0))
            throw new InvalidOperationException("Добавьте хотя бы одну позицию. Количество должно быть целым числом больше нуля.");
        if (lines.Select(l => l.StockId).Distinct().Count() != lines.Count)
            throw new InvalidOperationException("Одинаковые модель и размер должны находиться в одной строке заказа.");
        using NpgsqlConnection connection = OpenConnection();
        using NpgsqlTransaction transaction = connection.BeginTransaction();
        User user = RequireUser(connection, actor.Id);
        if (orderId.HasValue && !user.IsAdmin)
            throw new InvalidOperationException("Редактировать сохранённый заказ может только администратор.");
        if (!user.IsStaff && customerId != user.Id)
            throw new InvalidOperationException("Вы можете оформить заказ только на своё имя.");
        RequireUser(connection, customerId);
        List<CartLine> oldLines = new List<CartLine>();
        int id;
        if (orderId.HasValue)
        {
            using NpgsqlCommand find = Command(connection, "SELECT id FROM orders WHERE id = @p0 FOR UPDATE", orderId.Value);
            if (find.ExecuteScalar() == null)
                throw new InvalidOperationException("Заказ уже удалён. Обновите список.");
            id = orderId.Value;
            oldLines = ReadOrderLines(connection, id);
            ReturnStock(connection, id);
            using NpgsqlCommand delete = Command(connection, "DELETE FROM order_items WHERE order_id = @p0", id);
            delete.ExecuteNonQuery();
            using NpgsqlCommand update = Command(connection, "UPDATE orders SET order_date = @p0 WHERE id = @p1", DateOnly.FromDateTime(date), id);
            update.ExecuteNonQuery();
        }
        else
        {
            using NpgsqlCommand add = Command(connection, "INSERT INTO orders (order_date, user_id) VALUES (@p0, @p1) RETURNING id", DateOnly.FromDateTime(DateTime.Today), customerId);
            id = (int)add.ExecuteScalar()!;
        }
        Dictionary<int, Product> products = ReadProducts(connection, DateTime.Today).ToDictionary(p => p.Id);
        foreach (CartLine line in lines.OrderBy(l => l.StockId))
        {
            // Условие в UPDATE не даёт продать остаток дважды. Любая ошибка откатывает весь заказ.
            using NpgsqlCommand reserve = Command(connection,
                "UPDATE stock_items SET quantity = quantity - @p0 WHERE id = @p1 AND quantity >= @p0 RETURNING product_id", line.Quantity, line.StockId);
            object? productId = reserve.ExecuteScalar();
            if (productId == null)
                throw new InvalidOperationException($"Недостаточно товара «{line.Name}», размер {line.Size:0.#}. Обновите каталог и уменьшите количество.");
            CartLine? old = oldLines.FirstOrDefault(l => l.StockId == line.StockId);
            decimal price = old == null ? products[(int)productId].FinalPrice : old.UnitPrice;
            using NpgsqlCommand item = Command(connection,
                "INSERT INTO order_items (order_id, stock_item_id, quantity, unit_price) VALUES (@p0, @p1, @p2, @p3)", id, line.StockId, line.Quantity, price);
            item.ExecuteNonQuery();
        }
        transaction.Commit();
        return id;
    }

    private static void ReturnStock(NpgsqlConnection connection, int orderId)
    {
        using NpgsqlCommand command = Command(connection, """
            UPDATE stock_items si SET quantity = si.quantity + oi.quantity
            FROM order_items oi WHERE oi.stock_item_id = si.id AND oi.order_id = @p0
            """, orderId);
        command.ExecuteNonQuery();
    }

    public static void DeleteOrder(User actor, int orderId)
    {
        using NpgsqlConnection connection = OpenConnection();
        using NpgsqlTransaction transaction = connection.BeginTransaction();
        if (!RequireUser(connection, actor.Id).IsStaff)
            throw new InvalidOperationException("Удалять сохранённые заказы могут только менеджер и администратор.");
        using NpgsqlCommand find = Command(connection, "SELECT id FROM orders WHERE id = @p0 FOR UPDATE", orderId);
        if (find.ExecuteScalar() == null)
            throw new InvalidOperationException("Заказ уже удалён. Обновите список.");
        ReturnStock(connection, orderId);
        using NpgsqlCommand command = Command(connection, "DELETE FROM orders WHERE id = @p0", orderId);
        command.ExecuteNonQuery();
        transaction.Commit();
    }
}
