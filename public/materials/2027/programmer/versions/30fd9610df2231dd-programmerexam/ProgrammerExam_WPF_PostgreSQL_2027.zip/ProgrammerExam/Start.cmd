@echo off
cd /d "%~dp0"
if not exist "App\ShoeShop.exe" (
    echo Run Build.ps1 first.
    pause
    exit /b 1
)
start "" "App\ShoeShop.exe"
