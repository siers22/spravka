using System.ComponentModel;
using System.Windows;
using System.Windows.Input;

namespace ShoeShop;

public partial class MainWindow : Window
{
    private readonly User? user;
    private readonly bool pickerMode;
    private bool ready;
    private List<Product> products = new List<Product>();
    private List<CartLine> cart = new List<CartLine>();
    public CartLine? SelectedLine { get; private set; }

    public MainWindow(User? currentUser, bool selectForOrder = false)
    {
        InitializeComponent();
        user = currentUser;
        pickerMode = selectForOrder;
        UserNameText.Text = user?.FullName ?? "Гость";
        FiltersPanel.Visibility = user == null ? Visibility.Collapsed : Visibility.Visible;
        CartButton.Visibility = user == null || pickerMode ? Visibility.Collapsed : Visibility.Visible;
        OrdersButton.Visibility = user?.IsStaff == true && !pickerMode ? Visibility.Visible : Visibility.Collapsed;
        ExitButton.Content = pickerMode ? "Назад" : user == null ? "Войти" : "Выйти";
        if (pickerMode)
            Title = "Чудо Обувь — выбор товара для заказа";
        Loaded += (sender, args) => LoadCatalog();
        Closing += OnClosing;
    }

    private void LoadCatalog()
    {
        try
        {
            products = Db.GetProducts();
            if (!ready)
            {
                CategoryBox.ItemsSource = Db.GetCategories();
                CategoryBox.SelectedIndex = 0;
                ready = true;
            }
            ApplyFilters();
        }
        catch (Exception error)
        {
            Ui.Error(error);
        }
    }

    private void ApplyFilters()
    {
        int categoryId = CategoryBox.SelectedValue is int value ? value : 0;
        List<Product> visible = user == null ? products : Db.FilterProducts(products, SearchBox.Text, categoryId, SortBox.SelectedIndex);
        ProductsList.ItemsSource = visible;
        CountText.Text = $"Показано {visible.Count} из {products.Count} моделей. Красный фон: осталось не больше 3 пар.";
    }

    private void Filter_Changed(object sender, RoutedEventArgs e)
    {
        if (ready)
            ApplyFilters();
    }

    private void Product_Click(object sender, MouseButtonEventArgs e)
    {
        if (((FrameworkElement)sender).DataContext is not Product product)
            return;
        ProductWindow window = new ProductWindow(product.Id, user);
        window.Owner = this;
        if (window.ShowDialog() != true || window.SelectedLine == null)
            return;
        if (pickerMode)
        {
            SelectedLine = window.SelectedLine;
            DialogResult = true;
            return;
        }
        CartLine line = window.SelectedLine;
        CartLine? existing = cart.FirstOrDefault(l => l.StockId == line.StockId);
        int quantity = line.Quantity + (existing?.Quantity ?? 0);
        SizeOption? size = Db.GetSizes(product.Id).FirstOrDefault(s => s.StockId == line.StockId);
        if (size == null || quantity > size.Available)
        {
            Ui.Info("С учётом корзины выбрано больше пар, чем доступно. Уменьшите количество в корзине.");
            return;
        }
        if (existing == null)
            cart.Add(line);
        else
            existing.Quantity = quantity;
        UpdateCartButton();
        Ui.Info("Товар добавлен в корзину. Можно выбрать ещё товары или перейти к оформлению.");
    }

    private void UpdateCartButton()
    {
        CartButton.Content = $"Корзина ({cart.Sum(l => (long)l.Quantity)})";
    }

    private void Cart_Click(object sender, RoutedEventArgs e)
    {
        if (user == null)
            return;
        OrderWindow window = new OrderWindow(user, cart);
        window.Owner = this;
        window.ShowDialog();
        cart = window.Saved ? new List<CartLine>() : window.Lines;
        UpdateCartButton();
        LoadCatalog();
    }

    private void Orders_Click(object sender, RoutedEventArgs e)
    {
        if (user?.IsStaff != true)
            return;
        OrdersWindow window = new OrdersWindow(user);
        window.Owner = this;
        window.ShowDialog();
        LoadCatalog();
    }

    private void Refresh_Click(object sender, RoutedEventArgs e)
    {
        LoadCatalog();
    }

    private void Exit_Click(object sender, RoutedEventArgs e)
    {
        if (pickerMode)
        {
            Close();
            return;
        }
        if (cart.Count > 0 && !Ui.Confirm("При выходе несохранённая корзина будет очищена. Выйти?"))
            return;
        cart.Clear();
        new LoginWindow().Show();
        Close();
    }

    private void OnClosing(object? sender, CancelEventArgs e)
    {
        if (!pickerMode && cart.Count > 0)
            e.Cancel = !Ui.Confirm("Заказ ещё не оформлен. Закрыть каталог и очистить корзину?");
    }
}
