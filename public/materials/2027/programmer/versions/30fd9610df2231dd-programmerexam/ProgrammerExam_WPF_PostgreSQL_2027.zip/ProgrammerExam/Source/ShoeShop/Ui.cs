using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Npgsql;

namespace ShoeShop;

public static class Ui
{
    public static void Error(Exception error)
    {
        string message = error is NpgsqlException
            ? "Не удалось выполнить запрос к PostgreSQL. Проверьте запуск службы и параметры в database.json, затем повторите действие."
            : error.Message;
        MessageBox.Show(message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
    }

    public static void Info(string text)
    {
        MessageBox.Show(text, "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
    }

    public static bool Confirm(string text)
    {
        return MessageBox.Show(text, "Предупреждение", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.Yes;
    }

    public static void DigitsOnly(object sender, TextCompositionEventArgs e)
    {
        e.Handled = e.Text.Any(c => c < '0' || c > '9');
        if (e.Handled)
            Info("Количество вводится целым положительным числом, например 1 или 2.");
    }

    public static void CheckPaste(object sender, DataObjectPastingEventArgs e)
    {
        string? text = e.DataObject.GetData(DataFormats.UnicodeText) as string;
        if (string.IsNullOrEmpty(text) || text.Any(c => c < '0' || c > '9'))
        {
            e.CancelCommand();
            Info("В поле количества можно вставить только цифры.");
        }
    }

    public static int ReadQuantity(TextBox box)
    {
        if (!int.TryParse(box.Text, out int quantity) || quantity <= 0)
            throw new InvalidOperationException("Введите целое количество больше нуля, например 1 или 2.");
        return quantity;
    }
}
