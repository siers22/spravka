using System.Windows;
using System.Windows.Input;

namespace ShoeShop;

public partial class LoginWindow : Window
{
    public LoginWindow()
    {
        InitializeComponent();
        Loaded += (sender, args) => LoginBox.Focus();
    }

    private void SignIn_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(LoginBox.Text))
                throw new InvalidOperationException("Введите логин из списка пользователей.");
            User? user = Db.Login(LoginBox.Text);
            if (user == null)
                throw new InvalidOperationException("Такой логин не найден. Проверьте написание и раскладку клавиатуры.");
            OpenCatalog(user);
        }
        catch (Exception error)
        {
            Ui.Error(error);
        }
    }

    private void Guest_Click(object sender, RoutedEventArgs e)
    {
        OpenCatalog(null);
    }

    private void OpenCatalog(User? user)
    {
        MainWindow window = new MainWindow(user);
        window.Show();
        Close();
    }

    private void LoginBox_KeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Enter)
            SignIn_Click(sender, e);
    }
}
