using System.Windows;
using System.Windows.Input;

namespace ShoeShop;

public partial class ProductWindow : Window
{
    private readonly int productId;
    private Product? product;
    public CartLine? SelectedLine { get; private set; }

    public ProductWindow(int id, User? user)
    {
        InitializeComponent();
        productId = id;
        UserNameText.Text = user?.FullName ?? "Гость";
        OrderPanel.Visibility = user == null ? Visibility.Collapsed : Visibility.Visible;
        GuestText.Visibility = user == null ? Visibility.Visible : Visibility.Collapsed;
        Loaded += (sender, args) => LoadProduct();
    }

    private void LoadProduct()
    {
        try
        {
            product = Db.GetProducts().First(p => p.Id == productId);
            DataContext = product;
            List<SizeOption> sizes = Db.GetSizes(productId);
            SizeRangeText.Text = string.Join(";  ", sizes.Select(s => s.Display));
            List<SizeOption> available = sizes.Where(s => s.Available > 0).ToList();
            SizeBox.ItemsSource = available;
            SizeBox.SelectedIndex = available.Count > 0 ? 0 : -1;
            AddButton.IsEnabled = available.Count > 0;
            if (available.Count == 0)
                SizeRangeText.Text += "\nНет доступных для заказа размеров.";
        }
        catch (Exception error)
        {
            AddButton.IsEnabled = false;
            Ui.Error(error);
        }
    }

    private void Add_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            if (product == null || SizeBox.SelectedItem is not SizeOption size)
                throw new InvalidOperationException("Выберите доступный размер обуви.");
            int quantity = Ui.ReadQuantity(QuantityBox);
            if (quantity > size.Available)
                throw new InvalidOperationException($"Доступно только {size.Available} пар выбранного размера. Уменьшите количество.");
            SelectedLine = new CartLine
            {
                StockId = size.StockId, Name = product.Name, Manufacturer = product.Manufacturer,
                Size = size.Size, Quantity = quantity, UnitPrice = product.FinalPrice
            };
            DialogResult = true;
        }
        catch (Exception error)
        {
            Ui.Error(error);
        }
    }

    private void Back_Click(object sender, RoutedEventArgs e)
    {
        Close();
    }

    private void Quantity_Input(object sender, TextCompositionEventArgs e)
    {
        Ui.DigitsOnly(sender, e);
    }

    private void Quantity_Paste(object sender, DataObjectPastingEventArgs e)
    {
        Ui.CheckPaste(sender, e);
    }
}
