using System.Globalization;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using Npgsql;
using ShoeShop;

class Program
{
    private static int passed;
    private static int failed;

    [STAThread]
    static int Main(string[] args)
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;
        CultureInfo.DefaultThreadCurrentCulture = CultureInfo.GetCultureInfo("ru-RU");
        if (args.Length > 1 && args[0] == "--render")
        {
            RenderWindows(args[1]);
            return 0;
        }
        if (args.Length != 1 || !args[0].StartsWith("shoe_shop_check_"))
        {
            Console.WriteLine("Укажите имя отдельной тестовой базы shoe_shop_check_*. Рабочая база не используется.");
            return 1;
        }
        NpgsqlConnectionStringBuilder builder = new NpgsqlConnectionStringBuilder(Db.ConnectionString);
        builder.Database = args[0];
        Db.ConnectionString = builder.ConnectionString;
        RunChecks();
        Console.WriteLine($"ИТОГО: {passed} успешно, {failed} ошибок.");
        return failed == 0 ? 0 : 1;
    }

    private static void Check(string name, Action test)
    {
        try
        {
            test();
            passed++;
            Console.WriteLine("OK: " + name);
        }
        catch (Exception error)
        {
            failed++;
            Console.WriteLine("FAIL: " + name + " — " + error.Message);
        }
    }

    private static void Assert(bool condition)
    {
        if (!condition)
            throw new Exception("Условие проверки не выполнено.");
    }

    private static void Reject(Action action)
    {
        try
        {
            action();
        }
        catch (InvalidOperationException)
        {
            return;
        }
        throw new Exception("Некорректная операция была разрешена.");
    }

    private static object Scalar(string sql)
    {
        using NpgsqlConnection connection = new NpgsqlConnection(Db.ConnectionString);
        connection.Open();
        using NpgsqlCommand command = new NpgsqlCommand(sql, connection);
        return command.ExecuteScalar()!;
    }

    private static void Sql(string sql)
    {
        using NpgsqlConnection connection = new NpgsqlConnection(Db.ConnectionString);
        connection.Open();
        using NpgsqlCommand command = new NpgsqlCommand(sql, connection);
        command.ExecuteNonQuery();
    }

    private static CartLine Line(int stockId, int quantity = 1)
    {
        return new CartLine { StockId = stockId, Quantity = quantity, Name = "Тестовая модель", UnitPrice = 1 };
    }

    private static void RunChecks()
    {
        User admin = Db.Login("isivanov")!;
        User manager = Db.Login("papetrov")!;
        User client = Db.Login("asidorova")!;
        Check("Импорт: 20 пользователей, 31 модель, 35 размеров, 92 остатка, 10 заказов, 30 строк", () =>
        {
            Assert((long)Scalar("SELECT COUNT(*) FROM users") == 20);
            Assert((long)Scalar("SELECT COUNT(*) FROM products") == 31);
            Assert((long)Scalar("SELECT COUNT(*) FROM sizes") == 35);
            Assert((long)Scalar("SELECT COUNT(*) FROM stock_items") == 92);
            Assert((long)Scalar("SELECT COUNT(*) FROM orders") == 10);
            Assert((long)Scalar("SELECT COUNT(*) FROM order_items") == 30);
            Assert((long)Scalar("SELECT SUM(quantity) FROM stock_items") == 1274);
        });
        Check("10 таблиц и 9 внешних ключей", () =>
        {
            Assert((long)Scalar("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = 'public' AND table_type = 'BASE TABLE'") == 10);
            Assert((long)Scalar("SELECT COUNT(*) FROM information_schema.table_constraints WHERE table_schema = 'public' AND constraint_type = 'FOREIGN KEY'") == 9);
        });
        Check("Вход по логину: администратор, менеджер, клиент и ФИО", () =>
        {
            Assert(admin.IsAdmin && manager.IsStaff && !manager.IsAdmin && !client.IsStaff);
            Assert(admin.FullName == "Иванов Иван Сергеевич");
        });
        Check("Неизвестный логин не проходит", () => Assert(Db.Login("unknown") == null));
        Check("SQL-инъекция в логине не проходит", () => Assert(Db.Login("' OR 1=1 --") == null));
        Check("Пробелы вокруг логина удаляются", () => Assert(Db.Login(" isivanov ")!.Id == admin.Id));
        Check("Все категории загружены, первый элемент — Все категории", () =>
        {
            List<Category> categories = Db.GetCategories();
            Assert(categories.Count == 4 && categories[0].Id == 0 && categories[0].Name == "Все категории");
        });
        List<Product> may = Db.GetProducts(new DateTime(2026, 5, 10));
        Check("Скидка 25% для модели без заказов в апреле", () => Assert(may.Single(p => p.Id == 3).Discount == 25));
        Check("Нет скидки для модели с заказом в апреле", () => Assert(may.Single(p => p.Id == 1).Discount == 0));
        Check("Учитывается предыдущий календарный месяц, а не последние 30 дней", () => Assert(Db.GetProducts(new DateTime(2026, 5, 31)).Single(p => p.Id == 1).Discount == 0));
        Check("В июне учитываются майские заказы", () =>
        {
            List<Product> june = Db.GetProducts(new DateTime(2026, 6, 1));
            Assert(june.Single(p => p.Id == 2).Discount == 0);
            Assert(june.Single(p => p.Id == 1).Discount == 25);
        });
        Check("Начало текущего месяца не входит в предыдущий", () =>
        {
            Sql("INSERT INTO orders (id, order_date, user_id) VALUES (1000, '2026-05-01', 3); INSERT INTO order_items (order_id, stock_item_id, quantity, unit_price) SELECT 1000, MIN(id), 1, 100 FROM stock_items WHERE product_id=3;");
            Assert(Db.GetProducts(new DateTime(2026, 5, 1)).Single(p => p.Id == 3).Discount == 25);
        });
        Check("Последний день предыдущего месяца учитывается", () =>
        {
            Sql("UPDATE orders SET order_date='2026-04-30' WHERE id=1000;");
            Assert(Db.GetProducts(new DateTime(2026, 5, 1)).Single(p => p.Id == 3).Discount == 0);
        });
        Check("Переход года: январь проверяет декабрь", () =>
        {
            Sql("UPDATE orders SET order_date='2026-12-31' WHERE id=1000;");
            Assert(Db.GetProducts(new DateTime(2027, 1, 1)).Single(p => p.Id == 3).Discount == 0);
            Sql("DELETE FROM orders WHERE id=1000;");
        });
        Check("Расчёт цены и округление копеек", () =>
        {
            Assert(Product.CalculatePrice(2190, 25) == 1642.50m);
            Assert(Product.CalculatePrice(1990, 25) == 1492.50m);
            Assert(Product.CalculatePrice(10.02m, 25) == 7.52m);
        });
        Check("Количество суммируется по всем размерам", () => Assert(may.Single(p => p.Id == 1).Quantity == 120));
        Check("Мало при 5, много при 6; красный при 3, белый при 4", () =>
        {
            Assert(new Product { Quantity = 5 }.StockText == "мало");
            Assert(new Product { Quantity = 6 }.StockText == "много");
            Assert(new Product { Quantity = 3 }.CardBackground == "#ff8080");
            Assert(new Product { Quantity = 4 }.CardBackground == "#FFFFFF");
        });
        Check("Дробные размеры не потеряны", () => Assert(Db.GetSizes(20).Any(s => s.Size == 37.5m)));
        Check("Поиск по наименованию без учёта регистра", () => Assert(Db.FilterProducts(may, "КРОССОВКИ", 0, 0).Count > 0));
        Check("Поиск по описанию", () => Assert(Db.FilterProducts(may, "Смоленск", 0, 0).Single().Id == 1));
        Check("Поиск, категория и сортировка применяются совместно", () =>
        {
            List<Product> result = Db.FilterProducts(may, "кроссовки", may[0].CategoryId, 2);
            Assert(result.Count == 3 && result.All(p => p.CategoryId == may[0].CategoryId));
            Assert(result.Select(p => p.FinalPrice).SequenceEqual(result.Select(p => p.FinalPrice).OrderByDescending(p => p)));
        });
        Check("Сброс категории сохраняет поиск и сортировку", () =>
        {
            List<Product> result = Db.FilterProducts(may, "кроссовки", 0, 1);
            Assert(result.Count > 3);
            Assert(result.Select(p => p.FinalPrice).SequenceEqual(result.Select(p => p.FinalPrice).OrderBy(p => p)));
        });
        Check("Пустой результат поиска допустим", () => Assert(Db.FilterProducts(may, "несуществующая модель 123", 0, 0).Count == 0));
        Check("Картинка-заглушка при отсутствии файла", () => Assert(Path.GetFileName(Product.GetImagePath("missing.png")) == "picture.png"));
        Check("Файл изображения товара существует", () => Assert(File.Exists(Product.GetImagePath(may[0].ImageName))));
        Check("Цена импортированного заказа сохранена, сумма корректна", () => Assert(Db.GetOrders(admin).Single(o => o.Id == 1).Total == 4980m));
        Check("Состав заказа содержит модель, производителя, размер, количество и цену", () =>
        {
            List<CartLine> lines = Db.GetOrderLines(manager, 1);
            Assert(lines.Count == 2 && lines[0].Size == 20 && lines[0].Quantity == 1 && lines[0].UnitPrice == 2190);
            Assert(lines[0].Name.Contains("Звёздочка") && lines[0].Manufacturer == "Малыш-Спорт");
        });
        Check("Клиент не видит общий список заказов", () => Reject(() => Db.GetOrders(client)));
        Check("Клиент не видит чужой состав заказа", () => Reject(() => Db.GetOrderLines(client, 2)));
        Check("Пустой заказ запрещён", () => Reject(() => Db.SaveOrder(client, client.Id, DateTime.Today, new List<CartLine>())));
        Check("Нулевое и отрицательное количество запрещены", () =>
        {
            Reject(() => Db.SaveOrder(client, client.Id, DateTime.Today, new List<CartLine> { Line(1, 0) }));
            Reject(() => Db.SaveOrder(client, client.Id, DateTime.Today, new List<CartLine> { Line(1, -1) }));
        });
        Check("Клиент не оформляет заказ на другого клиента", () => Reject(() => Db.SaveOrder(client, admin.Id, DateTime.Today, new List<CartLine> { Line(1) })));
        Check("Одна товарная позиция не дублируется в заказе", () => Reject(() => Db.SaveOrder(client, client.Id, DateTime.Today, new List<CartLine> { Line(1), Line(1) })));
        int initialStock = Db.GetAvailableStock(1);
        long initialOrderCount = (long)Scalar("SELECT COUNT(*) FROM orders");
        int created = 0;
        Check("Подтверждение: заказ сохранён, дата текущая, остаток уменьшен на 2", () =>
        {
            created = Db.SaveOrder(client, client.Id, DateTime.Today, new List<CartLine> { Line(1, 2) });
            Assert(Db.GetAvailableStock(1) == initialStock - 2);
            Assert(Db.GetOrders(admin).Single(o => o.Id == created).Date.Date == DateTime.Today);
        });
        Check("Цена нового заказа рассчитывается из БД, произвольная цена игнорируется", () =>
        {
            decimal actual = Db.GetOrderLines(client, created).Single().UnitPrice;
            Assert(actual == Db.GetProducts().Single(p => p.Id == 1).FinalPrice && actual != 1);
        });
        Check("Изменение даты и количества администратором возвращает и резервирует остаток", () =>
        {
            Db.SaveOrder(admin, client.Id, new DateTime(2026, 7, 15), new List<CartLine> { Line(1, 1) }, created);
            Assert(Db.GetAvailableStock(1) == initialStock - 1);
            Assert(Db.GetOrders(admin).Single(o => o.Id == created).Date == new DateTime(2026, 7, 15));
        });
        Check("Цена существующей позиции сохраняется при редактировании", () =>
        {
            decimal before = Db.GetOrderLines(admin, created).Single().UnitPrice;
            Db.SaveOrder(admin, client.Id, DateTime.Today, new List<CartLine> { Line(1, 2) }, created);
            Assert(Db.GetOrderLines(admin, created).Single().UnitPrice == before);
        });
        Check("Администратор может добавить и удалить позиции сохранённого заказа", () =>
        {
            int secondStock = Db.GetAvailableStock(2);
            Db.SaveOrder(admin, client.Id, DateTime.Today, new List<CartLine> { Line(2, 2) }, created);
            Assert(Db.GetAvailableStock(1) == initialStock);
            Assert(Db.GetAvailableStock(2) == secondStock - 2);
            Db.SaveOrder(admin, client.Id, DateTime.Today, new List<CartLine> { Line(1, 2) }, created);
            Assert(Db.GetAvailableStock(2) == secondStock);
        });
        Check("Менеджер и клиент не редактируют сохранённый заказ", () =>
        {
            Reject(() => Db.SaveOrder(manager, client.Id, DateTime.Today, new List<CartLine> { Line(1) }, created));
            Reject(() => Db.SaveOrder(client, client.Id, DateTime.Today, new List<CartLine> { Line(1) }, created));
        });
        Check("Нельзя заказать больше остатка; не сохраняется даже первая допустимая позиция", () =>
        {
            int before = Db.GetAvailableStock(1);
            long orders = (long)Scalar("SELECT COUNT(*) FROM orders");
            Reject(() => Db.SaveOrder(client, client.Id, DateTime.Today, new List<CartLine> { Line(1), Line(2, 99999) }));
            Assert(Db.GetAvailableStock(1) == before && (long)Scalar("SELECT COUNT(*) FROM orders") == orders);
        });
        Check("Неудачное редактирование откатывает дату, состав и остаток", () =>
        {
            int before = Db.GetAvailableStock(1);
            DateTime date = Db.GetOrders(admin).Single(o => o.Id == created).Date;
            Reject(() => Db.SaveOrder(admin, client.Id, new DateTime(2000, 1, 1), new List<CartLine> { Line(1, 99999) }, created));
            Assert(Db.GetAvailableStock(1) == before);
            Assert(Db.GetOrderLines(admin, created).Single().Quantity == 2);
            Assert(Db.GetOrders(admin).Single(o => o.Id == created).Date == date);
        });
        Check("Клиент не удаляет сохранённый заказ", () => Reject(() => Db.DeleteOrder(client, created)));
        Check("Менеджер удаляет заказ: остаток восстановлен и строки удалены", () =>
        {
            Db.DeleteOrder(manager, created);
            Assert(Db.GetAvailableStock(1) == initialStock);
            Assert((long)Scalar("SELECT COUNT(*) FROM orders") == initialOrderCount);
            Assert((long)Scalar($"SELECT COUNT(*) FROM order_items WHERE order_id={created}") == 0);
        });
        Check("Повторное удаление не увеличивает остаток", () =>
        {
            Reject(() => Db.DeleteOrder(admin, created));
            Assert(Db.GetAvailableStock(1) == initialStock);
        });
        Check("Менеджер создаёт заказ на выбранного клиента", () =>
        {
            int id = Db.SaveOrder(manager, client.Id, DateTime.Today, new List<CartLine> { Line(1) });
            Assert(Db.GetOrders(manager).Single(o => o.Id == id).UserId == client.Id);
            Db.DeleteOrder(admin, id);
        });
        Check("Параллельные покупки не дают отрицательный остаток", () =>
        {
            int stockId = (int)Scalar("SELECT id FROM stock_items WHERE quantity=1 LIMIT 1");
            int success = 0;
            Parallel.For(0, 2, _ =>
            {
                try
                {
                    Db.SaveOrder(client, client.Id, DateTime.Today, new List<CartLine> { Line(stockId) });
                    Interlocked.Increment(ref success);
                }
                catch (InvalidOperationException) { }
            });
            Assert(success == 1 && Db.GetAvailableStock(stockId) == 0);
            Order last = Db.GetOrders(admin).First(o => o.Id > 10);
            Db.DeleteOrder(admin, last.Id);
            Assert(Db.GetAvailableStock(stockId) == 1);
        });
        Check("Подмена роли в объекте не даёт прав администратора", () =>
        {
            User fake = new User { Id = client.Id, RoleId = 1 };
            Reject(() => Db.DeleteOrder(fake, 1));
        });
        Check("Отсутствующий пользователь не может сохранить заказ", () => Reject(() => Db.SaveOrder(new User { Id = -1 }, -1, DateTime.Today, new List<CartLine> { Line(1) })));
        Check("Ограничения БД запрещают отрицательный остаток", () =>
        {
            try { Sql("UPDATE stock_items SET quantity=-1 WHERE id=1"); }
            catch (PostgresException error) when (error.SqlState == "23514") { return; }
            throw new Exception("CHECK отсутствует.");
        });
        Check("После всех операций исходные заказы и остатки сохранены", () =>
        {
            Assert((long)Scalar("SELECT COUNT(*) FROM orders") == 10);
            Assert((long)Scalar("SELECT COUNT(*) FROM order_items") == 30);
            Assert((long)Scalar("SELECT SUM(quantity) FROM stock_items") == 1274);
        });
    }

    private static void RenderWindows(string folder)
    {
        Directory.CreateDirectory(folder);
        App app = new App();
        app.DispatcherUnhandledException += (sender, args) =>
        {
            Console.Error.WriteLine(args.Exception);
            Environment.Exit(3);
        };
        app.InitializeComponent();
        app.StartupUri = new Uri("/ShoeShop;component/LoginWindow.xaml", UriKind.Relative);
        app.ShutdownMode = ShutdownMode.OnExplicitShutdown;
        app.Dispatcher.Invoke(() => { }, DispatcherPriority.ApplicationIdle);
        foreach (Window startupWindow in app.Windows.Cast<Window>().ToArray())
            startupWindow.Close();
        User admin = Db.Login("isivanov")!;
        User manager = Db.Login("papetrov")!;
        User client = Db.Login("asidorova")!;
        Render(new LoginWindow(), folder, "01-login");
        Render(new MainWindow(null), folder, "02-guest-catalog");
        Render(new MainWindow(client), folder, "03-client-catalog", w =>
        {
            ((TextBox)w.FindName("SearchBox")).Text = "ботинки";
            ((ComboBox)w.FindName("SortBox")).SelectedIndex = 1;
        });
        Render(new ProductWindow(20, client), folder, "04-product");
        List<CartLine> draft = new List<CartLine> { new CartLine { StockId=1, Name="Кроссовки детские «Звёздочка» экокожа", Manufacturer="Малыш-Спорт", Size=20, Quantity=2, UnitPrice=1642.50m } };
        Render(new OrderWindow(client, draft), folder, "05-cart");
        Render(new OrdersWindow(admin), folder, "06-orders");
        Order order = Db.GetOrders(admin).Single(o => o.Id == 3);
        Render(new OrderWindow(admin, existingOrder:order), folder, "07-admin-order");
        Render(new OrderWindow(manager, existingOrder:order), folder, "08-manager-order");
        app.Shutdown();
    }

    private static void Render(Window window, string folder, string name, Action<Window>? configure = null)
    {
        window.Show();
        configure?.Invoke(window);
        window.Dispatcher.Invoke(() => { }, DispatcherPriority.ApplicationIdle);
        window.UpdateLayout();
        RenderTargetBitmap bitmap = new RenderTargetBitmap((int)window.ActualWidth, (int)window.ActualHeight, 96, 96, PixelFormats.Pbgra32);
        DrawingVisual background = new DrawingVisual();
        using (DrawingContext context = background.RenderOpen())
            context.DrawRectangle(Brushes.White, null, new Rect(0, 0, window.ActualWidth, window.ActualHeight));
        bitmap.Render(background);
        bitmap.Render(window);
        PngBitmapEncoder encoder = new PngBitmapEncoder();
        encoder.Frames.Add(BitmapFrame.Create(bitmap));
        using FileStream stream = File.Create(Path.Combine(folder, name + ".png"));
        encoder.Save(stream);
        window.Close();
        Console.WriteLine("Rendered: " + name);
    }
}
