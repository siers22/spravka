﻿$ErrorActionPreference = 'Stop'
Push-Location $PSScriptRoot
try {
    dotnet restore Source\ShoeShop.sln --disable-parallel
    if ($LASTEXITCODE -ne 0) { throw 'Не удалось восстановить Npgsql.' }
    dotnet build Source\ShoeShop.sln -c Release --no-restore -p:UseSharedCompilation=false
    if ($LASTEXITCODE -ne 0) { throw 'Ошибка сборки.' }
    dotnet publish Source\ShoeShop -c Release --no-restore --self-contained false -o App
    if ($LASTEXITCODE -ne 0) { throw 'Не удалось создать исполняемые файлы.' }
}
finally { Pop-Location }
